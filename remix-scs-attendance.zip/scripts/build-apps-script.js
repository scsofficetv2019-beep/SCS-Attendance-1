import fs from 'fs';
import path from 'path';

const assetsDir = 'dist/assets';
if (!fs.existsSync(assetsDir)) {
  console.error('dist/assets directory does not exist! Run vite build first.');
  process.exit(1);
}

const files = fs.readdirSync(assetsDir);
const cssFile = files.find(f => f.endsWith('.css'));
const jsFile = files.find(f => f.endsWith('.js'));

if (!cssFile || !jsFile) {
  console.error('CSS or JS file not found in dist/assets');
  process.exit(1);
}

const css = fs.readFileSync(path.join(assetsDir, cssFile), 'utf8');
const js = fs.readFileSync(path.join(assetsDir, jsFile), 'utf8');

// CRITICAL: Escape all closing HTML tags in JavaScript to prevent HTML parsers (like Google Apps Script's HtmlService) from prematurely terminating tags
const safeJs = js
  .replace(/<\/script/gi, '<\\/script')
  .replace(/<\/body/gi, '<\\/body')
  .replace(/<\/html/gi, '<\\/html')
  .replace(/<\/head/gi, '<\\/head')
  .replace(/<\/style/gi, '<\\/style');

const finalHtml = `<!doctype html>
<html lang="bn">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>SCS ATTENDANCE</title>
    <meta name="description" content="Smart employee attendance and leave management system with GPS clock-in, PIN authentication, detailed monthly matrix reports, and administrative controls." />
    <meta property="og:title" content="SCS ATTENDANCE" />
    <meta property="og:description" content="Smart employee attendance and leave management system with GPS clock-in, PIN authentication, detailed monthly matrix reports, and administrative controls." />
    <meta property="og:type" content="website" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <style>
${css}
    </style>
  </head>
  <body class="bg-[#f5f5f7] text-[#1c1c1e] font-['Hind_Siliguri',sans-serif] antialiased min-h-screen">
    <div id="root">
      <div style="min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #f5f5f7; color: #1c1c1e; font-family: 'Hind Siliguri', sans-serif;">
        <div style="width: 44px; height: 44px; border: 4px solid #fce4ec; border-top: 4px solid #e91e63; border-radius: 50%; animation: spin 0.8s linear infinite;"></div>
        <p style="margin-top: 14px; font-weight: 700; font-size: 16px; color: #e91e63;">SCS Attendance চালু হচ্ছে...</p>
      </div>
    </div>
    <script>
${safeJs}
    </script>
  </body>
</html>`;

// Ensure both directories exist
['apps-script', 'app'].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Write HTML outputs
const outputDirs = ['apps-script', 'app'];
outputDirs.forEach(dir => {
  fs.writeFileSync(path.join(dir, 'Index.html'), finalHtml, 'utf8');
  fs.writeFileSync(path.join(dir, 'index.html'), finalHtml, 'utf8');
});

// Read source Code.gs
let codeGsContent = '';
if (fs.existsSync('apps-script/Code.gs')) {
  codeGsContent = fs.readFileSync('apps-script/Code.gs', 'utf8');
} else if (fs.existsSync('apps-script/code.gs')) {
  codeGsContent = fs.readFileSync('apps-script/code.gs', 'utf8');
}

if (codeGsContent) {
  outputDirs.forEach(dir => {
    fs.writeFileSync(path.join(dir, 'Code.gs'), codeGsContent, 'utf8');
    fs.writeFileSync(path.join(dir, 'code.gs'), codeGsContent, 'utf8');
  });
}

console.log('Successfully bundled standalone Apps Script files in both /app and /apps-script! Size:', (finalHtml.length / 1024).toFixed(1), 'KB');
