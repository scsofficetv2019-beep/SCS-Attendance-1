import { StrictMode, Component, type ReactNode, type ErrorInfo } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class RootErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('RootErrorBoundary caught error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#fff1f2',
          color: '#be123c',
          padding: '24px',
          fontFamily: 'sans-serif'
        }}>
          <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px' }}>
            অ্যাপ লোড হতে সমস্যা হয়েছে (App Error)
          </h2>
          <p style={{ fontSize: '14px', marginBottom: '16px', color: '#881337' }}>
            {this.state.error?.message || 'Unknown error occurred'}
          </p>
          <button
            onClick={() => window.location.reload()}
            style={{
              background: '#e11d48',
              color: '#ffffff',
              padding: '10px 20px',
              borderRadius: '8px',
              border: 'none',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}
          >
            রিলোড করুন (Reload)
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

let hasMounted = false;

function mountApp() {
  if (hasMounted) return true;
  try {
    const container = document.getElementById('root');
    if (container) {
      hasMounted = true;
      if (typeof window !== 'undefined') {
        (window as any).__scs_mounted = true;
      }
      const root = createRoot(container);
      root.render(
        <StrictMode>
          <RootErrorBoundary>
            <App />
          </RootErrorBoundary>
        </StrictMode>,
      );
      return true;
    }
  } catch (err) {
    console.error('Fatal mountApp error:', err);
  }
  return false;
}

// 1. Try mounting immediately
if (!mountApp()) {
  // 2. If not ready, listen to events and poll
  if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', mountApp);
  }
  if (typeof window !== 'undefined') {
    window.addEventListener('load', mountApp);
    const interval = setInterval(() => {
      if (mountApp()) {
        clearInterval(interval);
      }
    }, 20);
    setTimeout(() => clearInterval(interval), 3000);
  }
}



