import { useState, useEffect, useCallback } from 'react';
import {
  Employee,
  AttendanceRecord,
  OfficeSetup,
  DriveSetup,
} from './types';
import {
  loadEmployees,
  saveEmployees,
  loadAttendance,
  saveAttendance,
  loadOfficeSetup,
  saveOfficeSetup,
  loadDriveSetup,
  saveDriveSetup,
  safeGetItem,
  safeSetItem,
} from './utils/storage';
import { Language, Theme, translations } from './i18n';
import { UserLogin } from './components/UserLogin';
import { AdminLoginModal } from './components/AdminLoginModal';
import { TopNav, NavTab } from './components/TopNav';
import { Dashboard } from './components/Dashboard';
import { AttendanceMarking } from './components/AttendanceMarking';
import { LeaveRecord } from './components/LeaveRecord';
import { AdminPanel } from './components/AdminPanel';
import { GeneralModal, Toast } from './components/Modals';
import { ShieldCheck } from 'lucide-react';

declare global {
  interface Window {
    google?: any;
  }
}

export default function App() {
  // Authentication states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [isAdminLoginModalOpen, setIsAdminLoginModalOpen] = useState(false);

  // Language & Theme State
  const [language, setLanguage] = useState<Language>(() => {
    return (safeGetItem('scs_language') as Language) || 'bn';
  });
  const [theme, setTheme] = useState<Theme>(() => {
    return (safeGetItem('scs_theme') as Theme) || 'light';
  });

  const t = translations[language];

  // Navigation
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');

  // Application Data
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [officeSetup, setOfficeSetup] = useState<OfficeSetup>({
    officeInTime: '09:00',
    officeOutTime: '17:00',
    maxLateMinutes: '15',
    holidays: [],
  });
  const [driveSetup, setDriveSetup] = useState<DriveSetup>({
    folderId: '',
    folderUrl: '',
  });

  const [isSyncing, setIsSyncing] = useState(false);

  // Modals & Feedback
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
  }>({
    isOpen: false,
    title: '',
    message: '',
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  const showModal = useCallback((title: string, message: string) => {
    setModalState({ isOpen: true, title, message });
  }, []);

  const closeModal = useCallback(() => {
    setModalState((prev) => ({ ...prev, isOpen: false }));
  }, []);

  // Theme effect on HTML document
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    safeSetItem('scs_theme', theme);
  }, [theme]);

  // Language effect
  useEffect(() => {
    safeSetItem('scs_language', language);
  }, [language]);

  const toggleLanguage = () => {
    const nextLang = language === 'bn' ? 'en' : 'bn';
    setLanguage(nextLang);
    showToast(nextLang === 'bn' ? 'ভাষা: বাংলা' : 'Language: English');
  };

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    showToast(nextTheme === 'dark' ? t.darkMode : t.lightMode);
  };

  // Initial Data Load
  useEffect(() => {
    const emps = loadEmployees();
    const att = loadAttendance();
    const off = loadOfficeSetup();
    const drv = loadDriveSetup();

    setEmployees(emps);
    setAttendance(att);
    setOfficeSetup(off);
    setDriveSetup(drv);

    // If running in Google Apps Script Web App iframe, load live data from Google Sheets
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      window.google.script.run
        .withSuccessHandler((serverData: any) => {
          if (serverData) {
            if (serverData.employees && Array.isArray(serverData.employees) && serverData.employees.length > 0) {
              setEmployees(serverData.employees);
              saveEmployees(serverData.employees);
            }
            if (serverData.attendance && Array.isArray(serverData.attendance)) {
              setAttendance(serverData.attendance);
              saveAttendance(serverData.attendance);
            }
            if (serverData.officeSetup) {
              setOfficeSetup(serverData.officeSetup);
              saveOfficeSetup(serverData.officeSetup);
            }
            if (serverData.driveSetup) {
              setDriveSetup(serverData.driveSetup);
              saveDriveSetup(serverData.driveSetup);
            }
          }
        })
        .withFailureHandler((err: any) => {
          console.warn('Apps Script getInitialData fallback:', err);
        })
        .getInitialData();
    }
  }, []);

  // Auto-hide toast
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Sync / Refresh Handler
  const handleSync = () => {
    setIsSyncing(true);
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      window.google.script.run
        .withSuccessHandler((serverData: any) => {
          if (serverData) {
            if (serverData.employees?.length) {
              setEmployees(serverData.employees);
              saveEmployees(serverData.employees);
            }
            if (serverData.attendance) {
              setAttendance(serverData.attendance);
              saveAttendance(serverData.attendance);
            }
            if (serverData.officeSetup) {
              setOfficeSetup(serverData.officeSetup);
              saveOfficeSetup(serverData.officeSetup);
            }
            if (serverData.driveSetup) {
              setDriveSetup(serverData.driveSetup);
              saveDriveSetup(serverData.driveSetup);
            }
          }
          setIsSyncing(false);
          showToast(language === 'bn' ? 'গুগল শিট থেকে ডাটা সিঙ্ক সম্পন্ন হয়েছে' : 'Synced from Google Sheets');
        })
        .withFailureHandler(() => {
          const emps = loadEmployees();
          const att = loadAttendance();
          const off = loadOfficeSetup();
          const drv = loadDriveSetup();
          setEmployees(emps);
          setAttendance(att);
          setOfficeSetup(off);
          setDriveSetup(drv);
          setIsSyncing(false);
          showToast(language === 'bn' ? 'ডাটা সিঙ্ক সম্পন্ন হয়েছে' : 'Data synchronized successfully');
        })
        .getInitialData();
    } else {
      setTimeout(() => {
        const emps = loadEmployees();
        const att = loadAttendance();
        const off = loadOfficeSetup();
        const drv = loadDriveSetup();

        setEmployees(emps);
        setAttendance(att);
        setOfficeSetup(off);
        setDriveSetup(drv);

        setIsSyncing(false);
        showToast(language === 'bn' ? 'ডাটা সিঙ্ক সম্পন্ন হয়েছে' : 'Data synchronized successfully');
      }, 500);
    }
  };

  const handleUpdateEmployees = (newEmps: Employee[]) => {
    setEmployees(newEmps);
    saveEmployees(newEmps);
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      window.google.script.run.updateEmployeeList(newEmps);
    }
  };

  const handleUpdateAttendance = (newAttendance: AttendanceRecord[]) => {
    setAttendance(newAttendance);
    saveAttendance(newAttendance);
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      window.google.script.run.updateAttendanceList(newAttendance);
    }
  };

  const handleAddAttendanceRecord = (newRecord: AttendanceRecord) => {
    const updated = [newRecord, ...attendance];
    setAttendance(updated);
    saveAttendance(updated);
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      window.google.script.run.saveAttendanceRecord(newRecord);
    }
  };

  const handleUpdateOfficeSetup = (newSetup: OfficeSetup) => {
    setOfficeSetup(newSetup);
    saveOfficeSetup(newSetup);
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      window.google.script.run.updateOfficeSettings(newSetup);
    }
  };

  const handleUpdateDriveSetup = (newDrive: DriveSetup) => {
    setDriveSetup(newDrive);
    saveDriveSetup(newDrive);
    if (typeof window !== 'undefined' && window.google?.script?.run) {
      window.google.script.run.updateDriveSettings(newDrive);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdminUnlocked(false);
    setCurrentTab('dashboard');
    showToast(language === 'bn' ? 'সফলভাবে প্রস্থান করা হয়েছে' : 'Logged out successfully');
  };

  // If not logged in, show User Login screen
  if (!isLoggedIn) {
    return (
      <div className={theme === 'dark' ? 'dark' : ''}>
        <UserLogin
          onSuccess={() => {
            setIsLoggedIn(true);
            showToast(language === 'bn' ? 'লগইন সফল হয়েছে' : 'Login successful');
          }}
          onError={(msg) => showModal(t.invalidPin, msg)}
          language={language}
        />
        <GeneralModal
          isOpen={modalState.isOpen}
          title={modalState.title}
          message={modalState.message}
          onClose={closeModal}
        />
        <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
      </div>
    );
  }

  return (
    <div className={`min-h-screen flex flex-col bg-[#f5f5f7] dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200`}>
      {/* Top Header & Navigation with Pink Background Layer */}
      <TopNav
        currentTab={currentTab}
        onTabChange={(tab) => {
          setCurrentTab(tab);
        }}
        onSync={handleSync}
        onLogout={handleLogout}
        isSyncing={isSyncing}
        language={language}
        theme={theme}
        onToggleLanguage={toggleLanguage}
        onToggleTheme={toggleTheme}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-3 sm:p-6 pb-20">
        {currentTab === 'dashboard' && (
          <Dashboard
            employees={employees}
            attendance={attendance}
            language={language}
          />
        )}

        {currentTab === 'attendance' && (
          <AttendanceMarking
            employees={employees}
            attendance={attendance}
            onSubmitRecord={handleAddAttendanceRecord}
            onShowModal={showModal}
            onShowToast={showToast}
            language={language}
          />
        )}

        {currentTab === 'leave' && (
          <LeaveRecord
            employees={employees}
            attendance={attendance}
            officeSetup={officeSetup}
            language={language}
          />
        )}

        {currentTab === 'admin' && (
          <div>
            {!isAdminUnlocked ? (
              <div className="max-w-md mx-auto bg-white dark:bg-slate-900 rounded-3xl p-8 sm:p-10 text-center shadow-sm border border-slate-100 dark:border-slate-800 my-8 animate-fade transition-colors">
                <div className="w-20 h-20 mx-auto mb-4 bg-pink-100 dark:bg-pink-950/60 text-[#e91e63] dark:text-pink-400 rounded-full flex items-center justify-center shadow-xs">
                  <ShieldCheck className="w-10 h-10" />
                </div>
                <h2 className="text-2xl font-extrabold text-[#e91e63] mb-2">
                  {t.adminAccessRequired}
                </h2>
                <p className="text-slate-600 dark:text-slate-400 font-semibold mb-6 text-sm sm:text-base">
                  {t.adminLoginPrompt}
                </p>
                <button
                  type="button"
                  onClick={() => setIsAdminLoginModalOpen(true)}
                  className="w-full py-4 px-6 rounded-2xl bg-[#e91e63] text-white font-extrabold text-base hover:bg-[#c2185b] shadow-md transition active:scale-98 cursor-pointer"
                >
                  {t.loginAsAdmin}
                </button>
              </div>
            ) : (
              <AdminPanel
                employees={employees}
                attendance={attendance}
                officeSetup={officeSetup}
                driveSetup={driveSetup}
                onUpdateEmployees={handleUpdateEmployees}
                onUpdateAttendance={handleUpdateAttendance}
                onUpdateOfficeSetup={handleUpdateOfficeSetup}
                onUpdateDriveSetup={handleUpdateDriveSetup}
                onLockAdmin={() => {
                  setIsAdminUnlocked(false);
                  showToast(t.adminLocked);
                }}
                onShowModal={showModal}
                onShowToast={showToast}
                language={language}
              />
            )}
          </div>
        )}
      </main>

      {/* Admin Login Modal */}
      <AdminLoginModal
        isOpen={isAdminLoginModalOpen}
        onSuccess={() => {
          setIsAdminLoginModalOpen(false);
          setIsAdminUnlocked(true);
          showToast(language === 'bn' ? 'প্রশাসক লগইন সফল হয়েছে' : 'Admin login successful');
        }}
        onClose={() => setIsAdminLoginModalOpen(false)}
        onError={(msg) => showModal(t.invalidAdminPin, msg)}
        language={language}
      />

      {/* General Alert Modal */}
      <GeneralModal
        isOpen={modalState.isOpen}
        title={modalState.title}
        message={modalState.message}
        onClose={closeModal}
      />

      {/* Toast Notification */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
    </div>
  );
}
