import { Employee, AttendanceRecord, OfficeSetup, DriveSetup, MonthlyReportData, EmployeeMonthlyReport, DayStatus, LateDetail } from '../types';

export const USER_PIN = '2019';
export const ADMIN_PIN = '2026';

const STORAGE_KEYS = {
  EMPLOYEES: 'scs_attendance_employees',
  ATTENDANCE: 'scs_attendance_records',
  OFFICE: 'scs_attendance_office',
  DRIVE: 'scs_attendance_drive',
};

export function getAvatarUrl(name: string): string {
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'User')}&background=e91e63&color=fff&size=256`;
}

export function fixDriveUrl(url: string): string {
  if (!url) return '';
  const str = url.toString().trim();
  const match = str.match(/[-\w]{25,}/);
  if (match && (str.includes('drive.google.com') || str.includes('docs.google.com'))) {
    return `https://lh3.googleusercontent.com/d/${match[0]}`;
  }
  return str;
}

export function formatDateLocal(d: Date): string {
  const year = d.getFullYear();
  const month = ('0' + (d.getMonth() + 1)).slice(-2);
  const day = ('0' + d.getDate()).slice(-2);
  return `${year}-${month}-${day}`;
}

export function formatTimeLocal(d: Date): string {
  return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
}

export function formatTime12Hour(t: string): string {
  if (!t || t === '-') return '-';
  if (t.includes('AM') || t.includes('PM')) return t;
  const parts = t.split(':');
  let h = parseInt(parts[0], 10);
  const m = parseInt(parts[1] || '0', 10);
  if (isNaN(h)) return t;
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  if (h === 0) h = 12;
  return ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2) + ' ' + ampm;
}

export function parseTime12(t: string): number {
  if (!t || t === '-') return 0;
  const isPM = t.includes('PM');
  const clean = t.replace('AM', '').replace('PM', '').trim();
  const parts = clean.split(':');
  let h = parseInt(parts[0] || '0', 10);
  const m = parseInt(parts[1] || '0', 10);
  if (isPM && h < 12) h += 12;
  if (!isPM && h === 12) h = 0;
  return h * 60 + m;
}

export function diffMinutes(t1: string, t2: string): number {
  return parseTime12(t2) - parseTime12(t1);
}

export function calculateLateMinutes(time12: string, officeInTime: string, maxLateMinsStr: string): number {
  if (!time12 || time12 === '-') return 0;
  const official12 = formatTime12Hour(officeInTime);
  const diff = diffMinutes(official12, time12);
  const grace = parseInt(maxLateMinsStr || '0', 10);
  if (diff > grace) {
    return diff;
  }
  return 0;
}

export interface MonthDayInfo {
  dateStr: string;
  dayName: string;
  isFriday: boolean;
}

export function getMonthDays(ym: string): MonthDayInfo[] {
  const parts = ym.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const result: MonthDayInfo[] = [];
  for (let d = 1; d <= daysInMonth; d++) {
    const dt = new Date(year, month, d);
    const dateStr = `${year}-${('0' + (month + 1)).slice(-2)}-${('0' + d).slice(-2)}`;
    const dayIndex = dt.getDay();
    result.push({
      dateStr,
      dayName: dayNames[dayIndex],
      isFriday: dayIndex === 5,
    });
  }
  return result;
}

export function hoursBetween(t1: string, t2: string): string {
  let d = diffMinutes(t1, t2);
  if (d < 0) d += 24 * 60;
  return Math.floor(d / 60) + 'h ' + (d % 60) + 'm';
}

export function toMonthLabel(ym: string): string {
  const p = (ym || '').split('-');
  if (p.length < 2) return ym;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months[parseInt(p[1], 10) - 1] + ' ' + p[0];
}

// Initial Sample Data
const DEFAULT_EMPLOYEES: Employee[] = [
  {
    id: 'emp-001',
    name: 'মোঃ রফিকুল ইসলাম',
    empId: 'SCS-101',
    designation: 'অফিস ইনচার্জ (Supervisor)',
    department: 'Operations',
    mobile: '01711000001',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=256&h=256&fit=crop&crop=face',
    created: new Date().toISOString(),
    sortOrder: 1,
  },
  {
    id: 'emp-002',
    name: 'তানজিলা আক্তার',
    empId: 'SCS-102',
    designation: 'সিনিয়র অ্যাকাউন্ট্যান্ট',
    department: 'Accounts & Finance',
    mobile: '01711000002',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=256&h=256&fit=crop&crop=face',
    created: new Date().toISOString(),
    sortOrder: 2,
  },
  {
    id: 'emp-003',
    name: 'কামরুল হাসান',
    empId: 'SCS-103',
    designation: 'ফিল্ড এক্সিকিউটিভ',
    department: 'Field Operations',
    mobile: '01711000003',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=256&h=256&fit=crop&crop=face',
    created: new Date().toISOString(),
    sortOrder: 3,
  },
  {
    id: 'emp-004',
    name: 'সাদিয়া রহমান',
    empId: 'SCS-104',
    designation: 'অ্যাসিস্ট্যান্ট কো-অর্ডিনেটর',
    department: 'Coordination',
    mobile: '01711000004',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=256&h=256&fit=crop&crop=face',
    created: new Date().toISOString(),
    sortOrder: 4,
  },
  {
    id: 'emp-005',
    name: 'আব্দুল মোমিন',
    empId: 'SCS-105',
    designation: 'আইটি অ্যান্ড ডাটা সাপোর্ট',
    department: 'IT Support',
    mobile: '01711000005',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=256&h=256&fit=crop&crop=face',
    created: new Date().toISOString(),
    sortOrder: 5,
  },
];

const DEFAULT_OFFICE: OfficeSetup = {
  officeInTime: '09:00',
  officeOutTime: '17:00',
  maxLateMinutes: '15',
  holidays: ['2026-09-04 (Friday)', '2026-09-11 (Friday)', '2026-09-18 (Friday)', '2026-09-25 (Friday)', '2026-09-16 (Eid-e-Miladunnabi)'],
};

const DEFAULT_DRIVE: DriveSetup = {
  folderId: '1AbCdEfGhIjKlMnOpQrStUvWxYz',
  folderUrl: 'https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQrStUvWxYz',
};

// Seed attendance for current month and today
function createInitialAttendance(): AttendanceRecord[] {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const today = now.getDate();
  const records: AttendanceRecord[] = [];

  // Generate some past records for the current month
  for (let d = 1; d <= today; d++) {
    const dObj = new Date(year, month, d);
    if (dObj.getDay() === 5) continue; // Skip Fridays
    const dayStr = `${year}-${('0' + (month + 1)).slice(-2)}-${('0' + d).slice(-2)}`;

    // emp-001 (SCS-101): Present on time
    records.push({
      id: `att-${d}-1-in`,
      empId: 'SCS-101',
      date: dayStr,
      type: 'Clock IN',
      time: '08:52 AM',
      lat: 23.8103,
      lng: 90.4125,
      locationText: '23.8103,90.4125',
      note: 'Normal Entry',
      createdBy: 'user',
    });
    if (d < today) {
      records.push({
        id: `att-${d}-1-out`,
        empId: 'SCS-101',
        date: dayStr,
        type: 'Clock Out',
        time: '05:10 PM',
        lat: 23.8105,
        lng: 90.4126,
        locationText: '23.8105,90.4126',
        createdBy: 'user',
      });
    }

    // emp-002 (SCS-102): Present, late on some days
    const isLate = d % 4 === 0;
    records.push({
      id: `att-${d}-2-in`,
      empId: 'SCS-102',
      date: dayStr,
      type: 'Clock IN',
      time: isLate ? '09:28 AM' : '08:58 AM',
      lat: 23.8103,
      lng: 90.4125,
      locationText: '23.8103,90.4125',
      note: isLate ? 'ট্রাফিক জ্যামের জন্য দেরি হয়েছে' : '',
      createdBy: 'user',
    });
    if (d < today) {
      records.push({
        id: `att-${d}-2-out`,
        empId: 'SCS-102',
        date: dayStr,
        type: 'Clock Out',
        time: '05:05 PM',
        lat: 23.8104,
        lng: 90.4125,
        createdBy: 'user',
      });
    }

    // emp-003 (SCS-103): Present on most days, absent on 2 days
    if (d !== 3 && d !== 10) {
      records.push({
        id: `att-${d}-3-in`,
        empId: 'SCS-103',
        date: dayStr,
        type: 'Clock IN',
        time: '09:05 AM',
        lat: 23.8102,
        lng: 90.4124,
        locationText: '23.8102,90.4124',
        createdBy: 'user',
      });
      if (d < today) {
        records.push({
          id: `att-${d}-3-out`,
          empId: 'SCS-103',
          date: dayStr,
          type: 'Clock Out',
          time: '05:15 PM',
          lat: 23.8102,
          lng: 90.4124,
          createdBy: 'user',
        });
      }
    }

    // emp-004 (SCS-104)
    if (d !== 7) {
      records.push({
        id: `att-${d}-4-in`,
        empId: 'SCS-104',
        date: dayStr,
        type: 'Clock IN',
        time: '08:45 AM',
        lat: 23.8103,
        lng: 90.4125,
        locationText: '23.8103,90.4125',
        createdBy: 'user',
      });
      if (d < today) {
        records.push({
          id: `att-${d}-4-out`,
          empId: 'SCS-104',
          date: dayStr,
          type: 'Clock Out',
          time: '05:00 PM',
          lat: 23.8103,
          lng: 90.4125,
          createdBy: 'user',
        });
      }
    }

    // emp-005 (SCS-105)
    records.push({
      id: `att-${d}-5-in`,
      empId: 'SCS-105',
      date: dayStr,
      type: 'Clock IN',
      time: '09:10 AM',
      lat: 23.8103,
      lng: 90.4125,
      locationText: '23.8103,90.4125',
      createdBy: 'user',
    });
    if (d < today) {
      records.push({
        id: `att-${d}-5-out`,
        empId: 'SCS-105',
        date: dayStr,
        type: 'Clock Out',
        time: '05:30 PM',
        lat: 23.8103,
        lng: 90.4125,
        createdBy: 'user',
      });
    }
  }

  return records;
}

const memoryStorage: Record<string, string> = {};

export function safeGetItem(key: string): string | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage.getItem(key);
    }
  } catch (err) {
    // Ignore iframe security error
  }
  return memoryStorage[key] || null;
}

export function safeSetItem(key: string, value: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  } catch (err) {
    // Ignore iframe security error
  }
  memoryStorage[key] = value;
}

export function loadEmployees(): Employee[] {
  try {
    const raw = safeGetItem(STORAGE_KEYS.EMPLOYEES);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.sort((a, b) => a.sortOrder - b.sortOrder);
      }
    }
  } catch (e) {
    console.error('Failed to load employees', e);
  }
  saveEmployees(DEFAULT_EMPLOYEES);
  return DEFAULT_EMPLOYEES;
}

export function saveEmployees(employees: Employee[]): void {
  try {
    safeSetItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(employees));
  } catch (e) {
    console.error('Failed to save employees', e);
  }
}

export function loadAttendance(): AttendanceRecord[] {
  try {
    const raw = safeGetItem(STORAGE_KEYS.ATTENDANCE);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.error('Failed to load attendance', e);
  }
  const initial = createInitialAttendance();
  saveAttendance(initial);
  return initial;
}

export function saveAttendance(records: AttendanceRecord[]): void {
  try {
    safeSetItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(records));
  } catch (e) {
    console.error('Failed to save attendance', e);
  }
}

export function loadOfficeSetup(): OfficeSetup {
  try {
    const raw = safeGetItem(STORAGE_KEYS.OFFICE);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    }
  } catch (e) {
    console.error('Failed to load office setup', e);
  }
  saveOfficeSetup(DEFAULT_OFFICE);
  return DEFAULT_OFFICE;
}

export function saveOfficeSetup(setup: OfficeSetup): void {
  try {
    safeSetItem(STORAGE_KEYS.OFFICE, JSON.stringify(setup));
  } catch (e) {
    console.error('Failed to save office setup', e);
  }
}

export function loadDriveSetup(): DriveSetup {
  try {
    const raw = safeGetItem(STORAGE_KEYS.DRIVE);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    }
  } catch (e) {
    console.error('Failed to load drive setup', e);
  }
  saveDriveSetup(DEFAULT_DRIVE);
  return DEFAULT_DRIVE;
}

export function saveDriveSetup(setup: DriveSetup): void {
  try {
    safeSetItem(STORAGE_KEYS.DRIVE, JSON.stringify(setup));
  } catch (e) {
    console.error('Failed to save drive setup', e);
  }
}

export function resetAllData(): {
  employees: Employee[];
  attendance: AttendanceRecord[];
  officeSetup: OfficeSetup;
  driveSetup: DriveSetup;
} {
  saveEmployees(DEFAULT_EMPLOYEES);
  const initialAtt = createInitialAttendance();
  saveAttendance(initialAtt);
  saveOfficeSetup(DEFAULT_OFFICE);
  saveDriveSetup(DEFAULT_DRIVE);
  return {
    employees: DEFAULT_EMPLOYEES,
    attendance: initialAtt,
    officeSetup: DEFAULT_OFFICE,
    driveSetup: DEFAULT_DRIVE,
  };
}

// Generate Monthly Report matching code.gs exact calculation
export function generateMonthlyReport(
  monthStr: string, // YYYY-MM
  emps: Employee[],
  attendance: AttendanceRecord[],
  setup: OfficeSetup
): MonthlyReportData {
  const officeIn = setup.officeInTime || '09:00';
  const officeOut = setup.officeOutTime || '17:00';
  const grace = parseInt(setup.maxLateMinutes || '15', 10);

  const holidayListRaw = setup.holidays || [];
  const holidayDates = holidayListRaw.map((h) => h.split(' ')[0]);

  const parts = monthStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const daysInMonth = new Date(year, month, 0).getDate();

  const report: EmployeeMonthlyReport[] = [];
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  for (let e = 0; e < emps.length; e++) {
    const emp = emps[e];
    const empAttendance = attendance.filter(
      (a) => String(a.empId) === String(emp.empId) && (a.date || '').startsWith(monthStr)
    );

    const recordsByDay: { [day: string]: AttendanceRecord[] } = {};
    for (const a of empAttendance) {
      const day = a.date.slice(8, 10);
      if (!recordsByDay[day]) recordsByDay[day] = [];
      recordsByDay[day].push(a);
    }

    const days: DayStatus[] = [];
    let present = 0;
    let absent = 0;
    let late = 0;
    const lateDetails: LateDetail[] = [];

    for (let d = 1; d <= daysInMonth; d++) {
      const ds = ('0' + d).slice(-2);
      const fullDate = `${monthStr}-${ds}`;
      const dateObj = new Date(year, month - 1, d);
      const dayName = dayNames[dateObj.getDay()];
      const isHoliday = holidayDates.includes(fullDate) || dateObj.getDay() === 5; // Friday or configured holiday

      const recs = recordsByDay[ds] || [];
      let inRec: AttendanceRecord | null = null;
      let outRec: AttendanceRecord | null = null;

      for (const r of recs) {
        if (r.type === 'Clock IN') inRec = r;
        if (r.type === 'Clock Out') outRec = r;
      }

      if (inRec) {
        let status: DayStatus['status'] = isHoliday ? 'Present (Holiday)' : 'Present';
        const lateMin = diffMinutes(officeIn, inRec.time);
        let lateText = '';

        if (!isHoliday && lateMin > grace) {
          status = 'Present with Late';
          lateText = `+${lateMin} min`;
          late++;
          lateDetails.push({ date: fullDate, time: inRec.time, lateMinutes: lateMin });
        }
        present++;

        days.push({
          day: d,
          fullDate,
          dayName,
          status,
          lateText,
          inTime: inRec.time,
          outTime: outRec ? outRec.time : '-',
          workingHours: inRec && outRec ? hoursBetween(inRec.time, outRec.time) : '-',
          inLocation: inRec.lat ? { lat: inRec.lat, lng: inRec.lng ?? 0 } : null,
          outLocation: outRec && outRec.lat ? { lat: outRec.lat, lng: outRec.lng ?? 0 } : null,
          reason: inRec.note || '',
        });
      } else if (isHoliday) {
        days.push({
          day: d,
          fullDate,
          dayName,
          status: 'Holiday',
          lateText: '',
          inTime: '-',
          outTime: '-',
          workingHours: '-',
          inLocation: null,
          outLocation: null,
        });
      } else {
        days.push({
          day: d,
          fullDate,
          dayName,
          status: 'Absent',
          lateText: '',
          inTime: '-',
          outTime: '-',
          workingHours: '-',
          inLocation: null,
          outLocation: null,
        });
        absent++;
      }
    }

    report.push({
      employee: emp,
      summary: { present, absent, late },
      lateDetails,
      days,
    });
  }

  return {
    month: monthStr,
    monthLabel: toMonthLabel(monthStr),
    daysInMonth,
    report,
    officeInTime: officeIn,
    officeOutTime: officeOut,
    holidays: holidayListRaw,
  };
}

export function exportAttendanceData(
  payload: { type: string; months?: string[]; year?: number },
  emps: Employee[],
  attendance: AttendanceRecord[],
  setup: OfficeSetup
): { csvUrl: string; printableHtml: string } {
  let months: string[] = payload.months || [];
  const curYear = payload.year || new Date().getFullYear();

  if (payload.type === '1year') {
    months = [];
    for (let m = 1; m <= 12; m++) months.push(`${curYear}-${('0' + m).slice(-2)}`);
  } else if (payload.type === '2year') {
    months = [];
    for (let y = curYear; y < curYear + 2; y++) {
      for (let m = 1; m <= 12; m++) months.push(`${y}-${('0' + m).slice(-2)}`);
    }
  }

  const reports: MonthlyReportData[] = months.map((m) =>
    generateMonthlyReport(m, emps, attendance, setup)
  );

  const csvLines: string[] = [
    'Month,Employee Name,Emp ID,Designation,Total Days,Present Days,Absent Days,Late Days',
  ];

  for (const rep of reports) {
    for (const empRep of rep.report) {
      const emp = empRep.employee;
      csvLines.push(
        `"${rep.monthLabel}","${emp.name}","${emp.empId}","${emp.designation || ''}",${rep.daysInMonth},${empRep.summary.present},${empRep.summary.absent},${empRep.summary.late}`
      );
    }
  }

  const csvString = csvLines.join('\n');
  const csvBlob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  const csvUrl = URL.createObjectURL(csvBlob);

  const cStyle = '<' + '/style>';
  const cHead = '<' + '/head>';
  const cBody = '<' + '/body>';
  const cHtml = '<' + '/html>';

  let html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>SCS Attendance Export Report</title><style>
    body { font-family: 'Hind Siliguri', -apple-system, BlinkMacSystemFont, sans-serif; padding: 20px; color: #1c1c1e; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 26px; font-size: 13px; }
    th, td { border: 1.5px solid #2c2c2e; padding: 8px 10px; text-align: center; }
    th { background: #e91e63; color: #fff; font-size: 14px; font-weight: 800; }
    h2 { text-align: center; color: #e91e63; font-size: 24px; margin-bottom: 4px; }
    h3 { color: #333; margin-top: 20px; }
    .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
    @media print {
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      body { padding: 0; }
      table { page-break-after: always; }
    }
  ${cStyle}${cHead}<body>
    <h2>SCS ATTENDANCE SUMMARY REPORT</h2>
    <div style="text-align:center;font-size:14px;color:#666;margin-bottom:20px;">Generated on: ${new Date().toLocaleDateString('bn-BD')} ${new Date().toLocaleTimeString()}</div>`;

  for (const rep of reports) {
    html += `<h3>Month: ${rep.monthLabel}</h3>`;
    html += `<table><thead><tr>
      <th>SL</th>
      <th>Employee Name</th>
      <th>Emp ID</th>
      <th>Designation</th>
      <th>Total Days</th>
      <th>Present</th>
      <th>Absent</th>
      <th>Late</th>
    </tr></thead><tbody>`;

  rep.report.forEach((empRep, idx) => {
      const emp = empRep.employee;
      html += `<tr>
        <td>${idx + 1}</td>
        <td style="text-align:left;font-weight:700;">${emp.name}</td>
        <td>${emp.empId}</td>
        <td>${emp.designation || '-'}</td>
        <td>${rep.daysInMonth}</td>
        <td style="color:#34c759;font-weight:800;">${empRep.summary.present}</td>
        <td style="color:#ff3b30;font-weight:800;">${empRep.summary.absent}</td>
        <td style="color:#e91e63;font-weight:800;">${empRep.summary.late}</td>
      </tr>`;
    });

    html += `</tbody></table>`;
  }

  html += `<div class="footer">SCS Attendance System &bull; Confidential Office Record</div>${cBody}${cHtml}`;

  return { csvUrl, printableHtml: html };
}
