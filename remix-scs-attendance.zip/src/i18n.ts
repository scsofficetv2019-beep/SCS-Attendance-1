export type Language = 'bn' | 'en';
export type Theme = 'light' | 'dark';

export interface Translations {
  appName: string;
  userLogin: string;
  adminLogin: string;
  enterPin: string;
  enterAdminPin: string;
  clear: string;
  cancel: string;
  invalidPin: string;
  invalidAdminPin: string;
  dashboard: string;
  attendance: string;
  leaveRecord: string;
  admin: string;
  sync: string;
  logout: string;
  login: string;
  signup: string;
  lightMode: string;
  darkMode: string;
  overview: string;
  totalEmployees: string;
  todayAttendance: string;
  presentToday: string;
  absentToday: string;
  todayStatus: string;
  noEmployees: string;
  markAttendance: string;
  attendanceType: string;
  selectClockType: string;
  clockIn: string;
  clockOut: string;
  tapToSelectEmployee: string;
  selectEmployeeBtn: string;
  selectEmployeeModalTitle: string;
  searchEmployeePlaceholder: string;
  location: string;
  getCurrentLocation: string;
  fetchingGps: string;
  gpsCaptured: string;
  gpsNotice: string;
  submitAttendance: string;
  leaveSummaryTab: string;
  leaveDetailTab: string;
  shortSummaryTitle: string;
  detailSummaryTitle: string;
  print: string;
  sl: string;
  photo: string;
  name: string;
  empId: string;
  designation: string;
  mobile: string;
  totalPresent: string;
  totalAbsent: string;
  totalLateDays: string;
  daysUnit: string;
  dateAndDays: string;
  metrics: string;
  checkInTime: string;
  checkOutTime: string;
  workingHours: string;
  checkInLocation: string;
  checkOutLocation: string;
  viewLocation: string;
  footerTotalPresent: string;
  footerTotalAbsent: string;
  footerTotalLate: string;
  lateDetailsTitle: string;
  date: string;
  time: string;
  late: string;
  ok: string;
  adminAccessRequired: string;
  adminLoginPrompt: string;
  loginAsAdmin: string;
  adminLocked: string;
  employeesTab: string;
  manualTab: string;
  attendanceManageTab: string;
  officeTab: string;
  driveTab: string;
  exportTab: string;
  lock: string;
  employeeList: string;
  addEmployee: string;
  editEmployee: string;
  saveEmployee: string;
  deleteEmployeeConfirm: string;
  fullName: string;
  department: string;
  photoUrl: string;
  uploadDevicePhoto: string;
  manualAttendanceTitle: string;
  selectEmployeePrompt: string;
  reasonOrNote: string;
  saveManualAttendance: string;
  filterSpecificDay: string;
  month: string;
  edit: string;
  del: string;
  saveChanges: string;
  officeSetupTitle: string;
  officeInTime: string;
  officeOutTime: string;
  maxLateGrace: string;
  holidaysSetup: string;
  addHoliday: string;
  saveOfficeSetup: string;
  driveSetupTitle: string;
  driveFolderId: string;
  driveFolderUrl: string;
  saveDriveSetup: string;
  exportAttendanceTitle: string;
  exportSelection: string;
  singleMonth: string;
  multipleMonths: string;
  oneYear: string;
  twoYears: string;
  exportPdfAndCsv: string;
  downloadCsv: string;
  viewPdf: string;
  minutesUnit: string;
  signupTitle: string;
  signupDesc: string;
  newPinPrompt: string;
  confirmPinPrompt: string;
  pinMismatch: string;
  signupSuccess: string;
  close: string;
}

export const translations: Record<Language, Translations> = {
  bn: {
    appName: 'এসসিএস হাজিরা',
    userLogin: 'ব্যবহারকারী প্রবেশ',
    adminLogin: 'প্রশাসক প্রবেশ',
    enterPin: '৪ সংখ্যার পিন দিন',
    enterAdminPin: '৪ সংখ্যার প্রশাসক পিন দিন',
    clear: 'মুছুন',
    cancel: 'বাতিল',
    invalidPin: 'ভুল পিন কোড',
    invalidAdminPin: 'ভুল প্রশাসক পিন কোড',
    dashboard: 'ড্যাশবোর্ড',
    attendance: 'হাজিরা',
    leaveRecord: 'ছুটির খতিয়ান',
    admin: 'প্রশাসক',
    sync: 'সিঙ্ক',
    logout: 'প্রস্থান',
    login: 'লগইন',
    signup: 'নিবন্ধন',
    lightMode: 'লাইট মোড',
    darkMode: 'ডার্ক মোড',
    overview: 'সার্বিক চিত্র',
    totalEmployees: 'মোট কর্মকর্তা-কর্মচারী',
    todayAttendance: 'আজকের হাজিরা সংখ্যা',
    presentToday: 'আজকে উপস্থিত',
    absentToday: 'আজকে অনুপস্থিত',
    todayStatus: 'আজকের অবস্থা',
    noEmployees: 'কোন কর্মকর্তা পাওয়া যায়নি',
    markAttendance: 'হাজিরা প্রদান',
    attendanceType: 'হাজিরার ধরন',
    selectClockType: '-- নির্বাচন করুন: প্রবেশ অথবা প্রস্থান --',
    clockIn: 'প্রবেশ হাজিরা',
    clockOut: 'প্রস্থান হাজিরা',
    tapToSelectEmployee: 'কর্মকর্তা নির্বাচন করতে স্পর্শ করুন',
    selectEmployeeBtn: 'কর্মকর্তা নির্বাচন',
    selectEmployeeModalTitle: 'কর্মকর্তা বাছাই করুন',
    searchEmployeePlaceholder: 'নাম অথবা আইডি দিয়ে খুঁজুন...',
    location: 'অবস্থান',
    getCurrentLocation: 'বর্তমান জিপিএস অবস্থান নিন',
    fetchingGps: 'জিপিএস খোঁজা হচ্ছে...',
    gpsCaptured: 'জিপিএস অবস্থান নেওয়া হয়েছে',
    gpsNotice: 'হাজিরা গ্রহণের পূর্বে ফোনের জিপিএস চালু রাখা আবশ্যক',
    submitAttendance: 'হাজিরা জমা দিন',
    leaveSummaryTab: 'সংক্ষিপ্ত সারসংক্ষেপ',
    leaveDetailTab: 'বিস্তারিত ম্যাট্রিক্স ছক',
    shortSummaryTitle: 'সংক্ষিপ্ত হাজিরা বিবরণী',
    detailSummaryTitle: 'মাসিক বিস্তারিত হাজিরা ছক',
    print: 'প্রিন্ট',
    sl: 'ক্রমিক',
    photo: 'ছবি',
    name: 'নাম',
    empId: 'আইডি',
    designation: 'পদবী',
    mobile: 'মোবাইল',
    totalPresent: 'মোট উপস্থিতি',
    totalAbsent: 'মোট অনুপস্থিতি',
    totalLateDays: 'মোট বিলম্ব দিন',
    daysUnit: 'দিন',
    dateAndDays: 'তারিখ ও দিন',
    metrics: 'বিবরণ',
    checkInTime: 'প্রবেশ সময়',
    checkOutTime: 'প্রস্থান সময়',
    workingHours: 'কর্মঘণ্টা',
    checkInLocation: 'প্রবেশের স্থান',
    checkOutLocation: 'প্রস্থানের স্থান',
    viewLocation: 'ম্যাপে দেখুন',
    footerTotalPresent: 'সর্বমোট উপস্থিতি',
    footerTotalAbsent: 'সর্বমোট অনুপস্থিতি',
    footerTotalLate: 'সর্বমোট বিলম্ব',
    lateDetailsTitle: 'বিলম্বের বিস্তারিত তালিকা',
    date: 'তারিখ',
    time: 'সময়',
    late: 'বিলম্ব',
    ok: 'ঠিক আছে',
    adminAccessRequired: 'প্রশাসক নিরাপত্তা আবশ্যক',
    adminLoginPrompt: 'প্রশাসক প্যানেলে প্রবেশের জন্য পিন দিন',
    loginAsAdmin: 'প্রশাসক হিসেবে প্রবেশ',
    adminLocked: 'প্রশাসক প্যানেল তালাবদ্ধ',
    employeesTab: 'কর্মকর্তাবৃন্দ',
    manualTab: 'হাতেকলমে এন্ট্রি',
    attendanceManageTab: 'হাজিরা ব্যবস্থাপনা',
    officeTab: 'অফিস সময়সূচি',
    driveTab: 'গুগল ড্রাইভ',
    exportTab: 'রপ্তানি',
    lock: 'তালাবদ্ধ',
    employeeList: 'কর্মকর্তা তালিকা',
    addEmployee: 'নতুন কর্মকর্তা যোগ',
    editEmployee: 'কর্মকর্তা সম্পাদনা',
    saveEmployee: 'সংরক্ষণ করুন',
    deleteEmployeeConfirm: 'আপনি কি নিশ্চিতভাবে এই কর্মকর্তাকে মুছে ফেলতে চান?',
    fullName: 'পূর্ণ নাম',
    department: 'বিভাগ',
    photoUrl: 'ছবির লিংক',
    uploadDevicePhoto: 'ডিভাইস থেকে ছবি আপলোড',
    manualAttendanceTitle: 'হাতেকলমে হাজিরা প্রদান',
    selectEmployeePrompt: 'কর্মকর্তা বেছে নিন',
    reasonOrNote: 'কারণ বা মন্তব্য',
    saveManualAttendance: 'হাতেকলমে হাজিরা সংরক্ষণ',
    filterSpecificDay: 'নির্দিষ্ট দিন বাছাই (ঐচ্ছিক)',
    month: 'মাস',
    edit: 'সম্পাদনা',
    del: 'মুছুন',
    saveChanges: 'পরিবর্তন সংরক্ষণ',
    officeSetupTitle: 'অফিস সময় ও ছুটির নিয়মাবলী',
    officeInTime: 'প্রবেশের সর্বোচ্চ সময়',
    officeOutTime: 'প্রস্থানের প্রমিত সময়',
    maxLateGrace: 'সর্বোচ্চ ছাড় মিনিট',
    holidaysSetup: 'ছুটির তালিকা',
    addHoliday: 'ছুটি যোগ',
    saveOfficeSetup: 'অফিস নিয়ম সংরক্ষণ',
    driveSetupTitle: 'গুগল ড্রাইভ সংযোগ',
    driveFolderId: 'ড্রাইভ ফোল্ডার আইডি',
    driveFolderUrl: 'ড্রাইভ ফোল্ডার লিংক',
    saveDriveSetup: 'ড্রাইভ সংযোগ সংরক্ষণ',
    exportAttendanceTitle: 'হাজিরা তথ্য রপ্তানি',
    exportSelection: 'রপ্তানির পরিধি',
    singleMonth: 'একটি নির্দিষ্ট মাস',
    multipleMonths: 'একাধিক মাস',
    oneYear: 'পূর্ণ এক বছর',
    twoYears: 'পূর্ণ দুই বছর',
    exportPdfAndCsv: 'পিডিএফ ও সিএসভি তৈরি করুন',
    downloadCsv: 'সিএসভি ডাউনলোড',
    viewPdf: 'পিডিএফ দেখুন / প্রিন্ট',
    minutesUnit: 'মিনিট',
    signupTitle: 'নতুন ব্যবহারকারী নিবন্ধন',
    signupDesc: 'আপনার নতুন ৪ সংখ্যার পিন নির্ধারণ করুন',
    newPinPrompt: 'নতুন পিন কোড',
    confirmPinPrompt: 'পিন নিশ্চিতকরণ',
    pinMismatch: 'পিন দুটি মেলেনি',
    signupSuccess: 'নিবন্ধন সম্পন্ন হয়েছে!',
    close: 'বন্ধ করুন',
  },
  en: {
    appName: 'SCS ATTENDANCE',
    userLogin: 'User Login',
    adminLogin: 'Admin Login',
    enterPin: 'Enter 4-digit PIN',
    enterAdminPin: 'Enter 4-digit Admin PIN',
    clear: 'Clear',
    cancel: 'Cancel',
    invalidPin: 'Invalid PIN Code',
    invalidAdminPin: 'Invalid Admin PIN Code',
    dashboard: 'Dashboard',
    attendance: 'Attendance',
    leaveRecord: 'Leave Record',
    admin: 'Admin',
    sync: 'Sync',
    logout: 'Logout',
    login: 'Login',
    signup: 'Sign Up',
    lightMode: 'Light Mode',
    darkMode: 'Dark Mode',
    overview: 'Overview',
    totalEmployees: 'Total Employees',
    todayAttendance: 'Today Logs',
    presentToday: 'Present Today',
    absentToday: 'Absent Today',
    todayStatus: 'Today Status',
    noEmployees: 'No employees found',
    markAttendance: 'Mark Attendance',
    attendanceType: 'Attendance Type',
    selectClockType: '-- Select Clock In or Clock Out --',
    clockIn: 'Clock IN',
    clockOut: 'Clock Out',
    tapToSelectEmployee: 'Tap to select employee',
    selectEmployeeBtn: 'Select Employee',
    selectEmployeeModalTitle: 'Select Employee',
    searchEmployeePlaceholder: 'Search by name or ID...',
    location: 'Location',
    getCurrentLocation: 'Get Current GPS Location',
    fetchingGps: 'Fetching GPS location...',
    gpsCaptured: 'GPS location captured',
    gpsNotice: 'Device GPS must be enabled before submitting',
    submitAttendance: 'Submit Attendance',
    leaveSummaryTab: 'Summary',
    leaveDetailTab: 'Detail Summary',
    shortSummaryTitle: 'Short Attendance Summary',
    detailSummaryTitle: 'Detailed Attendance Summary Matrix',
    print: 'Print',
    sl: 'SL',
    photo: 'Photo',
    name: 'Name',
    empId: 'Emp ID',
    designation: 'Designation',
    mobile: 'Mobile',
    totalPresent: 'Total Present',
    totalAbsent: 'Total Absent',
    totalLateDays: 'Total Late Days',
    daysUnit: 'Days',
    dateAndDays: 'Date & Days',
    metrics: 'Metrics',
    checkInTime: 'Check In Time',
    checkOutTime: 'Check Out Time',
    workingHours: 'Working Hours',
    checkInLocation: 'Check In Location',
    checkOutLocation: 'Check Out Location',
    viewLocation: 'View on Maps',
    footerTotalPresent: 'Total Present',
    footerTotalAbsent: 'Total Absent',
    footerTotalLate: 'Total Late',
    lateDetailsTitle: 'Late Arrival Log',
    date: 'Date',
    time: 'Time',
    late: 'Late',
    ok: 'OK',
    adminAccessRequired: 'Admin Access Required',
    adminLoginPrompt: 'Please enter admin PIN to unlock system controls',
    loginAsAdmin: 'Login as Admin',
    adminLocked: 'Admin Locked',
    employeesTab: 'Employees',
    manualTab: 'Manual',
    attendanceManageTab: 'Manage',
    officeTab: 'Office',
    driveTab: 'Drive',
    exportTab: 'Export',
    lock: 'Lock',
    employeeList: 'Employee List',
    addEmployee: 'Add Employee',
    editEmployee: 'Edit Employee',
    saveEmployee: 'Save Employee',
    deleteEmployeeConfirm: 'Are you sure you want to delete this employee?',
    fullName: 'Full Name',
    department: 'Department',
    photoUrl: 'Photo URL',
    uploadDevicePhoto: 'Upload Photo from Device',
    manualAttendanceTitle: 'Manual Attendance',
    selectEmployeePrompt: 'Choose Employee',
    reasonOrNote: 'Reason or Note',
    saveManualAttendance: 'Save Manual Record',
    filterSpecificDay: 'Filter Specific Day (Optional)',
    month: 'Month',
    edit: 'Edit',
    del: 'Delete',
    saveChanges: 'Save Changes',
    officeSetupTitle: 'Office Hours & Holiday Rules',
    officeInTime: 'Official In Time Limit',
    officeOutTime: 'Official Out Time Limit',
    maxLateGrace: 'Grace Period (Minutes)',
    holidaysSetup: 'Holidays List',
    addHoliday: 'Add Holiday',
    saveOfficeSetup: 'Save Office Setup',
    driveSetupTitle: 'Google Drive Integration',
    driveFolderId: 'Drive Folder ID',
    driveFolderUrl: 'Drive Folder URL',
    saveDriveSetup: 'Save Drive Setup',
    exportAttendanceTitle: 'Export Attendance Data',
    exportSelection: 'Export Scope',
    singleMonth: 'Single Month',
    multipleMonths: 'Multiple Months',
    oneYear: '1 Full Year',
    twoYears: '2 Full Years',
    exportPdfAndCsv: 'Generate PDF & CSV',
    downloadCsv: 'Download CSV',
    viewPdf: 'View PDF / Print',
    minutesUnit: 'min',
    signupTitle: 'New User Registration',
    signupDesc: 'Set your new 4-digit PIN for access',
    newPinPrompt: 'New PIN',
    confirmPinPrompt: 'Confirm PIN',
    pinMismatch: 'PINs do not match',
    signupSuccess: 'Registration successful!',
    close: 'Close',
  },
};
