import React from 'react';
import { X } from 'lucide-react';

interface GeneralModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  onClose: () => void;
}

export const GeneralModal: React.FC<GeneralModalProps> = ({
  isOpen,
  title,
  message,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="w-full max-w-sm sm:max-w-md bg-white rounded-3xl p-6 text-center shadow-2xl border border-slate-100 animate-fade">
        <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63] mb-3">
          {title}
        </h3>
        <p className="text-slate-700 text-base font-semibold mb-6 whitespace-pre-line leading-relaxed">
          {message}
        </p>
        <button
          type="button"
          onClick={onClose}
          className="w-full py-3.5 bg-[#e91e63] text-white font-extrabold text-base rounded-xl hover:bg-[#c2185b] transition shadow-md"
        >
          ঠিক আছে (OK)
        </button>
      </div>
    </div>
  );
};

interface ToastProps {
  message: string | null;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, onClose }) => {
  if (!message) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#1c1c1e] text-white px-5 py-3 rounded-full text-sm sm:text-base font-bold shadow-2xl flex items-center gap-3 animate-fade max-w-[90vw] border border-white/10">
      <span className="truncate">{message}</span>
      <button
        onClick={onClose}
        className="text-white/60 hover:text-white transition p-0.5"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
