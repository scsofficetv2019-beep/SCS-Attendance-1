import React, { useState } from 'react';
import {
  Employee,
  AttendanceRecord,
  OfficeSetup,
} from '../types';
import {
  getMonthDays,
  calculateLateMinutes,
  getAvatarUrl,
} from '../utils/storage';
import { Language, translations } from '../i18n';
import {
  FileSpreadsheet,
  Printer,
  Calendar,
  X,
  Clock,
  MapPin,
  LayoutGrid,
  Table as TableIcon,
  List,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from 'lucide-react';

interface LeaveRecordProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  officeSetup: OfficeSetup;
  language: Language;
}

type ViewMode = 'summary' | 'matrix' | 'grid' | 'list';

export const LeaveRecord: React.FC<LeaveRecordProps> = ({
  employees,
  attendance,
  officeSetup,
  language,
}) => {
  const t = translations[language];

  // Default to current month YYYY-MM
  const today = new Date();
  const currentYearMonth = `${today.getFullYear()}-${(
    '0' +
    (today.getMonth() + 1)
  ).slice(-2)}`;

  const [viewMode, setViewMode] = useState<ViewMode>('matrix');
  const [selectedMonth, setSelectedMonth] = useState<string>(currentYearMonth);
  const [searchEmployeeQuery, setSearchEmployeeQuery] = useState('');

  // Late details modal state
  const [selectedLateDetails, setSelectedLateDetails] = useState<{
    empName: string;
    records: { date: string; time: string; lateMins: number }[];
  } | null>(null);

  const monthDays = getMonthDays(selectedMonth);

  // Calculate Employee Month Stats
  const calculateEmployeeStats = (empId: string) => {
    let presentCount = 0;
    let absentCount = 0;
    const lateRecords: { date: string; time: string; lateMins: number }[] = [];

    monthDays.forEach((day) => {
      const isPastOrToday = day.dateStr <= today.toISOString().split('T')[0];
      const isHoliday =
        day.isFriday ||
        officeSetup.holidays.some((h) => h.includes(day.dateStr));

      // Find attendance for this employee on this day
      const dayLogs = attendance.filter(
        (a) => a.empId === empId && a.date === day.dateStr
      );

      const clockIn = dayLogs.find((a) => a.type === 'Clock IN');

      if (clockIn) {
        presentCount++;
        const lateMins = calculateLateMinutes(
          clockIn.time,
          officeSetup.officeInTime,
          officeSetup.maxLateMinutes
        );
        if (lateMins > 0) {
          lateRecords.push({
            date: day.dateStr,
            time: clockIn.time,
            lateMins,
          });
        }
      } else if (isPastOrToday && !isHoliday) {
        absentCount++;
      }
    });

    const totalTracked = presentCount + absentCount;
    const attendanceRate = totalTracked > 0 ? Math.round((presentCount / totalTracked) * 100) : 0;

    return {
      present: presentCount,
      absent: absentCount,
      lateDays: lateRecords.length,
      lateRecords,
      attendanceRate,
    };
  };

  const handlePrint = () => {
    window.print();
  };

  const filteredEmployees = employees.filter(
    (e) =>
      e.name.toLowerCase().includes(searchEmployeeQuery.toLowerCase()) ||
      e.empId.toLowerCase().includes(searchEmployeeQuery.toLowerCase())
  );

  return (
    <div className="space-y-5 animate-fade">
      {/* Top Filter and View Mode Switcher */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-3 sm:p-4 shadow-xs border border-slate-200 dark:border-slate-800 flex flex-wrap gap-2.5 items-center justify-between no-print transition-colors">
        {/* 4 View Modes */}
        <div className="flex flex-wrap gap-1.5 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
          <button
            onClick={() => setViewMode('summary')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl font-black text-xs transition cursor-pointer ${
              viewMode === 'summary'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <TableIcon className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'শর্ট সামারি' : 'Short Summary'}</span>
          </button>

          <button
            onClick={() => setViewMode('matrix')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl font-black text-xs transition cursor-pointer ${
              viewMode === 'matrix'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'ম্যাট্রিক্স ভিউ' : 'Matrix View'}</span>
          </button>

          <button
            onClick={() => setViewMode('grid')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl font-black text-xs transition cursor-pointer ${
              viewMode === 'grid'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'কার্ড ভিউ' : 'Card View'}</span>
          </button>

          <button
            onClick={() => setViewMode('list')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl font-black text-xs transition cursor-pointer ${
              viewMode === 'list'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <List className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'লিস্ট ভিউ' : 'List View'}</span>
          </button>
        </div>

        {/* Month Picker & Print Button */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
            <Calendar className="w-4 h-4 text-slate-500" />
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent font-bold text-slate-800 dark:text-slate-200 text-xs sm:text-sm outline-hidden cursor-pointer"
            />
          </div>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 py-1.5 px-3.5 bg-[#e91e63] hover:bg-[#c2185b] text-white rounded-xl font-black text-xs transition shadow-xs cursor-pointer active:scale-98"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{t.print}</span>
          </button>
        </div>
      </div>

      {/* 1. SHORT SUMMARY TAB (Distinct, separated rows and columns with crisp borders) */}
      {viewMode === 'summary' && (
        <div className="print-area bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 shadow-xs border border-slate-200 dark:border-slate-800 transition-colors">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-5">
            <div>
              <h2 className="text-xl font-black text-[#e91e63]">
                {t.shortSummaryTitle}
              </h2>
              <p className="text-xs font-bold text-slate-500 mt-0.5">
                {language === 'bn' ? `মাস: ${selectedMonth}` : `Month: ${selectedMonth}`}
              </p>
            </div>
            <button
              onClick={handlePrint}
              className="no-print flex items-center gap-1.5 py-1.5 px-3 bg-pink-50 dark:bg-pink-950/40 text-[#e91e63] rounded-xl font-bold text-xs hover:bg-pink-100 transition border border-pink-200 dark:border-pink-900 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.print}</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border-2 border-slate-300 dark:border-slate-700">
            <table className="w-full text-left border-collapse min-w-[760px]">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs uppercase tracking-wider font-black">
                  <th className="p-3 text-center border-r border-b-2 border-slate-300 dark:border-slate-700 w-14">
                    {t.sl}
                  </th>
                  <th className="p-3 text-center border-r border-b-2 border-slate-300 dark:border-slate-700 w-16">
                    {t.photo}
                  </th>
                  <th className="p-3 border-r border-b-2 border-slate-300 dark:border-slate-700">
                    {t.name}
                  </th>
                  <th className="p-3 text-center border-r border-b-2 border-slate-300 dark:border-slate-700 w-28">
                    {t.empId}
                  </th>
                  <th className="p-3 border-r border-b-2 border-slate-300 dark:border-slate-700">
                    {t.designation}
                  </th>
                  <th className="p-3 text-center text-emerald-700 dark:text-emerald-400 border-r border-b-2 border-slate-300 dark:border-slate-700 w-28">
                    {t.totalPresent}
                  </th>
                  <th className="p-3 text-center text-rose-700 dark:text-rose-400 border-r border-b-2 border-slate-300 dark:border-slate-700 w-28">
                    {t.totalAbsent}
                  </th>
                  <th className="p-3 text-center text-amber-700 dark:text-amber-400 border-b-2 border-slate-300 dark:border-slate-700 w-28">
                    {t.totalLateDays}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300 dark:divide-slate-700 text-sm font-semibold">
                {employees.map((emp, index) => {
                  const stats = calculateEmployeeStats(emp.empId);
                  return (
                    <tr
                      key={emp.id}
                      className="hover:bg-pink-50/50 dark:hover:bg-pink-950/20 transition group"
                    >
                      <td className="p-3 text-center font-bold text-slate-500 border-r border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40">
                        {index + 1}
                      </td>
                      <td className="p-3 text-center border-r border-slate-300 dark:border-slate-700">
                        <img
                          src={emp.photoUrl || getAvatarUrl(emp.name)}
                          alt={emp.name}
                          className="w-10 h-10 rounded-full mx-auto object-cover border border-slate-300 dark:border-slate-600"
                        />
                      </td>
                      <td className="p-3 font-black text-slate-900 dark:text-white group-hover:text-[#e91e63] border-r border-slate-300 dark:border-slate-700">
                        {emp.name}
                      </td>
                      <td className="p-3 text-center font-bold text-slate-600 dark:text-slate-300 border-r border-slate-300 dark:border-slate-700">
                        {emp.empId}
                      </td>
                      <td className="p-3 text-slate-600 dark:text-slate-300 border-r border-slate-300 dark:border-slate-700">
                        {emp.designation || '-'}
                      </td>
                      <td className="p-3 text-center font-black text-emerald-700 dark:text-emerald-400 border-r border-slate-300 dark:border-slate-700 bg-emerald-50/30 dark:bg-emerald-950/20">
                        {stats.present} {t.daysUnit}
                      </td>
                      <td className="p-3 text-center font-black text-rose-700 dark:text-rose-400 border-r border-slate-300 dark:border-slate-700 bg-rose-50/30 dark:bg-rose-950/20">
                        {stats.absent} {t.daysUnit}
                      </td>
                      <td className="p-3 text-center bg-amber-50/30 dark:bg-amber-950/20">
                        <button
                          type="button"
                          onClick={() => {
                            if (stats.lateDays > 0) {
                              setSelectedLateDetails({
                                empName: emp.name,
                                records: stats.lateRecords,
                              });
                            }
                          }}
                          className={`font-black text-sm px-3 py-1 rounded-full transition ${
                            stats.lateDays > 0
                              ? 'bg-amber-200 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200 hover:bg-amber-300 cursor-pointer shadow-xs'
                              : 'text-slate-400'
                          }`}
                        >
                          {stats.lateDays} {t.daysUnit}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. FULL 2D MATRIX VIEW (Entire Month, All Employees, 2D Freeze Panes & Swipe) */}
      {viewMode === 'matrix' && (
        <div className="print-area bg-white dark:bg-slate-900 rounded-3xl p-4 sm:p-6 shadow-xs border border-slate-200 dark:border-slate-800 transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 gap-2 mb-3">
            <div>
              <h2 className="text-xl font-black text-[#e91e63]">
                {t.detailSummaryTitle}
              </h2>
              <p className="text-xs font-bold text-slate-500">
                {language === 'bn' ? `মাস: ${selectedMonth} (সকল তারিখ ও কর্মকর্তা)` : `Month: ${selectedMonth}`}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden lg:flex items-center gap-2 text-xs font-black">
                <span className="text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700">
                  ■ {language === 'bn' ? 'কার্যদিবস' : 'Workday'}
                </span>
                <span className="text-amber-800 dark:text-amber-300 bg-amber-100/60 dark:bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-300 dark:border-amber-800">
                  ■ {language === 'bn' ? 'শুক্রবার' : 'Friday'}
                </span>
                <span className="text-emerald-800 dark:text-emerald-300 bg-emerald-100/60 dark:bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-300 dark:border-emerald-800">
                  ■ {language === 'bn' ? 'সরকারি ছুটি' : 'Holiday'}
                </span>
              </div>
              <button
                onClick={handlePrint}
                className="no-print flex items-center gap-1.5 py-1.5 px-3 bg-pink-50 dark:bg-pink-950/40 text-[#e91e63] rounded-xl font-bold text-xs hover:bg-pink-100 transition border border-pink-200 dark:border-pink-900 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{t.print}</span>
              </button>
            </div>
          </div>

          {/* Full Matrix Container:
              - Left 2 columns sticky horizontally (sticky left-0 and sticky left-[110px])
              - Top headers sticky vertically (sticky top-0)
              - Footers sticky bottom (sticky bottom-0)
              - Calming, eye-friendly Slate/Charcoal palette
              - Extra bold distinct divider border separating each employee
              - Both Check-In and Check-Out locations shown cleanly
          */}
          <div className="relative border-2 border-slate-300 dark:border-slate-700 rounded-2xl overflow-auto max-h-[82vh] touch-pan-x touch-pan-y overscroll-contain shadow-xs">
            <table className="w-max border-collapse text-xs select-none">
              {/* STICKY HEADER */}
              <thead className="sticky top-0 z-30 shadow-md">
                {/* Row 1: Employee Names */}
                <tr className="bg-slate-800 text-white">
                  <th
                    rowSpan={4}
                    className="sticky left-0 top-0 z-40 bg-slate-800 text-slate-100 p-2.5 text-center border-r border-b-2 border-slate-700 w-28 min-w-[110px] max-w-[110px] font-black uppercase tracking-wider text-xs"
                  >
                    {t.dateAndDays}
                  </th>
                  <th
                    rowSpan={4}
                    className="sticky left-[110px] top-0 z-40 bg-slate-800 text-slate-100 p-2.5 text-center border-r-4 border-b-2 border-slate-400 dark:border-slate-500 w-26 min-w-[104px] max-w-[104px] font-black uppercase tracking-wider text-xs"
                  >
                    {t.metrics}
                  </th>

                  {employees.map((emp) => (
                    <th
                      key={`emp-${emp.id}`}
                      colSpan={4}
                      className="p-2.5 text-center font-black text-sm border-r-4 border-b border-slate-700 border-r-slate-400 dark:border-r-slate-500 bg-slate-800 dark:bg-slate-900 text-white"
                    >
                      <div className="truncate max-w-[320px] mx-auto tracking-wide">{emp.name}</div>
                    </th>
                  ))}
                </tr>

                {/* Row 2: Designations */}
                <tr className="bg-[#253346] text-slate-200 font-bold">
                  {employees.map((emp) => (
                    <th
                      key={`desig-${emp.id}`}
                      colSpan={4}
                      className="p-1 text-center text-xs border-r-4 border-b border-slate-600 border-r-slate-400 dark:border-r-slate-500 bg-[#253346] dark:bg-slate-800 text-slate-200"
                    >
                      <div className="truncate max-w-[320px] mx-auto font-medium">
                        {emp.designation || '-'}
                      </div>
                    </th>
                  ))}
                </tr>

                {/* Row 3: Emp ID & Mobile */}
                <tr className="bg-[#334155] text-slate-300 font-bold">
                  {employees.map((emp) => (
                    <th
                      key={`id-${emp.id}`}
                      colSpan={4}
                      className="p-1 text-center text-xs border-r-4 border-b border-slate-600 border-r-slate-400 dark:border-r-slate-500 bg-[#334155] dark:bg-slate-750 text-slate-300"
                    >
                      <div className="truncate max-w-[320px] mx-auto">
                        {emp.empId} {emp.mobile ? `• ${emp.mobile}` : ''}
                      </div>
                    </th>
                  ))}
                </tr>

                {/* Row 4: Metrics Sub-headers */}
                <tr className="bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-100 font-black text-[11px]">
                  {employees.map((emp) => (
                    <React.Fragment key={`sub-${emp.id}`}>
                      <th className="p-2 text-center border-r border-b-2 border-slate-300 dark:border-slate-600 w-24 min-w-[96px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                        {t.checkInTime}
                      </th>
                      <th className="p-2 text-center border-r border-b-2 border-slate-300 dark:border-slate-600 w-24 min-w-[96px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                        {t.checkOutTime}
                      </th>
                      <th className="p-2 text-center border-r border-b-2 border-slate-300 dark:border-slate-600 w-20 min-w-[80px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                        {t.workingHours}
                      </th>
                      <th className="p-2 text-center border-r-4 border-b-2 border-slate-400 dark:border-slate-500 w-26 min-w-[104px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                        {language === 'bn' ? 'লোকেশন (ইন/আউট)' : 'Location (In/Out)'}
                      </th>
                    </React.Fragment>
                  ))}
                </tr>
              </thead>

              {/* TABLE BODY (Full Month, Day by Day) */}
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {monthDays.map((day) => {
                  const isHoliday = officeSetup.holidays.some((h) =>
                    h.includes(day.dateStr)
                  );

                  // Calming, gentle background colors that do NOT strain eyes
                  let rowBg = 'bg-white dark:bg-slate-900';
                  let dateBg = 'bg-slate-50 dark:bg-slate-850 text-slate-800 dark:text-slate-200';
                  let metricBg = 'bg-slate-50 dark:bg-slate-850 text-slate-600 dark:text-slate-400';

                  if (day.isFriday) {
                    rowBg = 'bg-amber-50/30 dark:bg-amber-950/15';
                    dateBg = 'bg-amber-100/70 dark:bg-amber-950/40 text-amber-950 dark:text-amber-200';
                    metricBg = 'bg-amber-100/70 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300';
                  } else if (isHoliday) {
                    rowBg = 'bg-emerald-50/30 dark:bg-emerald-950/15';
                    dateBg = 'bg-emerald-100/70 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-200';
                    metricBg = 'bg-emerald-100/70 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-300';
                  }

                  return (
                    <tr key={day.dateStr} className={`${rowBg} hover:bg-slate-100/60 dark:hover:bg-slate-800/60 transition`}>
                      {/* Sticky Column 1: Date & Day Name */}
                      <td
                        className={`sticky left-0 z-20 ${dateBg} p-2 text-center font-black border-r border-b border-slate-200 dark:border-slate-800 w-28 min-w-[110px] max-w-[110px] shadow-xs`}
                      >
                        <div className="leading-tight">
                          <div className="text-xs font-black">{day.dateStr}</div>
                          <div className="text-[10px] font-bold opacity-75">{day.dayName}</div>
                        </div>
                      </td>

                      {/* Sticky Column 2: Status Indicator */}
                      <td
                        className={`sticky left-[110px] z-20 ${metricBg} p-2 text-center font-bold border-r-4 border-b border-slate-400 dark:border-slate-500 w-26 min-w-[104px] max-w-[104px] shadow-xs`}
                      >
                        <span className="text-[10px] sm:text-[11px] font-extrabold">
                          {day.isFriday
                            ? (language === 'bn' ? 'শুক্রবার ছুটি' : 'Friday Holiday')
                            : isHoliday
                            ? (language === 'bn' ? 'সরকারি ছুটি' : 'Govt Holiday')
                            : (language === 'bn' ? 'কার্যদিবস' : 'Workday')}
                        </span>
                      </td>

                      {/* Employee Logs */}
                      {employees.map((emp, empIdx) => {
                        const dayLogs = attendance.filter(
                          (a) => a.empId === emp.empId && a.date === day.dateStr
                        );
                        const clockIn = dayLogs.find((a) => a.type === 'Clock IN');
                        const clockOut = dayLogs.find((a) => a.type === 'Clock Out');

                        let lateMins = 0;
                        if (clockIn) {
                          lateMins = calculateLateMinutes(
                            clockIn.time,
                            officeSetup.officeInTime,
                            officeSetup.maxLateMinutes
                          );
                        }

                        // Work hours calculation
                        let duration = '-';
                        if (clockIn && clockOut) {
                          try {
                            const [inTime, inPeriod] = clockIn.time.split(' ');
                            const [outTime, outPeriod] = clockOut.time.split(' ');
                            let [inH, inM] = inTime.split(':').map(Number);
                            let [outH, outM] = outTime.split(':').map(Number);
                            if (inPeriod === 'PM' && inH !== 12) inH += 12;
                            if (inPeriod === 'AM' && inH === 12) inH = 0;
                            if (outPeriod === 'PM' && outH !== 12) outH += 12;
                            if (outPeriod === 'AM' && outH === 12) outH = 0;

                            const inDate = new Date(2000, 0, 1, inH, inM);
                            const outDate = new Date(2000, 0, 1, outH, outM);
                            const diffMs = outDate.getTime() - inDate.getTime();
                            if (diffMs > 0) {
                              const diffHrs = Math.floor(diffMs / 3600000);
                              const diffMins = Math.floor((diffMs % 3600000) / 60000);
                              duration = `${diffHrs}h ${diffMins}m`;
                            }
                          } catch {
                            duration = '-';
                          }
                        }

                        // Subtle column grouping tint for alternating employees
                        const empColTint = empIdx % 2 === 1 ? 'bg-slate-50/50 dark:bg-slate-800/20' : '';

                        return (
                          <React.Fragment key={`${emp.id}-${day.dateStr}`}>
                            {/* Clock In */}
                            <td className={`p-2 text-center border-r border-b border-slate-200 dark:border-slate-800 w-24 min-w-[96px] font-bold ${empColTint}`}>
                              {clockIn ? (
                                <div className="leading-tight">
                                  <span className="text-emerald-700 dark:text-emerald-400 font-black">
                                    {clockIn.time}
                                  </span>
                                  {lateMins > 0 && (
                                    <div className="text-[10px] text-amber-700 dark:text-amber-400 font-extrabold mt-0.5">
                                      +{lateMins} {t.minutesUnit}
                                    </div>
                                  )}
                                </div>
                              ) : (
                                <span className="text-slate-400 font-normal">-</span>
                              )}
                            </td>

                            {/* Clock Out */}
                            <td className={`p-2 text-center border-r border-b border-slate-200 dark:border-slate-800 w-24 min-w-[96px] font-bold ${empColTint}`}>
                              {clockOut ? (
                                <span className="text-blue-700 dark:text-blue-400 font-black">
                                  {clockOut.time}
                                </span>
                              ) : (
                                <span className="text-slate-400 font-normal">-</span>
                              )}
                            </td>

                            {/* Working Hours */}
                            <td className={`p-2 text-center border-r border-b border-slate-200 dark:border-slate-800 w-20 min-w-[80px] font-bold text-slate-700 dark:text-slate-300 ${empColTint}`}>
                              {duration}
                            </td>

                            {/* Both Check-In and Check-Out Location (Distinct Bold Right Border for Employee Separator) */}
                            <td className={`p-2 text-center border-r-4 border-b border-slate-200 dark:border-slate-800 border-r-slate-400 dark:border-r-slate-500 w-26 min-w-[104px] ${empColTint}`}>
                              <div className="flex flex-col items-center justify-center gap-1">
                                {clockIn?.lat ? (
                                  <a
                                    href={`https://www.google.com/maps?q=${clockIn.lat},${clockIn.lng}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-0.5 text-[10px] font-black text-emerald-700 dark:text-emerald-300 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900 border border-emerald-300 dark:border-emerald-800 px-1.5 py-0.5 rounded transition shadow-2xs w-full max-w-[86px] justify-center"
                                    title={`${language === 'bn' ? 'প্রবেশ (ইন) লোকেশন' : 'In Location'}: ${clockIn.locationText || `${clockIn.lat}, ${clockIn.lng}`}`}
                                  >
                                    <MapPin className="w-2.5 h-2.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                                    <span className="truncate">{language === 'bn' ? 'ইন লোকেশন' : 'In Loc'}</span>
                                  </a>
                                ) : null}
                                {clockOut?.lat ? (
                                  <a
                                    href={`https://www.google.com/maps?q=${clockOut.lat},${clockOut.lng}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-0.5 text-[10px] font-black text-sky-700 dark:text-sky-300 bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/60 dark:hover:bg-sky-900 border border-sky-300 dark:border-sky-800 px-1.5 py-0.5 rounded transition shadow-2xs w-full max-w-[86px] justify-center"
                                    title={`${language === 'bn' ? 'প্রস্থান (আউট) লোকেশন' : 'Out Location'}: ${clockOut.locationText || `${clockOut.lat}, ${clockOut.lng}`}`}
                                  >
                                    <MapPin className="w-2.5 h-2.5 text-sky-600 dark:text-sky-400 shrink-0" />
                                    <span className="truncate">{language === 'bn' ? 'আউট লোকেশন' : 'Out Loc'}</span>
                                  </a>
                                ) : null}
                                {!clockIn?.lat && !clockOut?.lat && (
                                  <span className="text-slate-400 font-normal">-</span>
                                )}
                              </div>
                            </td>
                          </React.Fragment>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>

              {/* STICKY FOOTER (TOTAL PRESENT, TOTAL ABSENT, TOTAL LATE DAYS) */}
              <tfoot className="sticky bottom-0 z-30 font-black shadow-lg">
                {/* Total Present */}
                <tr className="bg-slate-800 text-emerald-300 border-t-2 border-b border-slate-700">
                  <td
                    colSpan={2}
                    className="sticky left-0 z-40 bg-slate-800 text-emerald-300 p-2.5 text-right pr-3 font-black border-r-4 border-slate-400 dark:border-slate-500 text-xs uppercase tracking-wider"
                  >
                    {t.footerTotalPresent}
                  </td>
                  {employees.map((emp) => {
                    const stats = calculateEmployeeStats(emp.empId);
                    return (
                      <td
                        key={`ft-pres-${emp.id}`}
                        colSpan={4}
                        className="p-2 text-center font-black text-sm border-r-4 border-slate-400 dark:border-slate-500 bg-slate-800 text-emerald-300"
                      >
                        {stats.present} {t.daysUnit}
                      </td>
                    );
                  })}
                </tr>

                {/* Total Absent */}
                <tr className="bg-slate-850 bg-[#1e293b] text-rose-300 border-b border-slate-700">
                  <td
                    colSpan={2}
                    className="sticky left-0 z-40 bg-slate-850 bg-[#1e293b] text-rose-300 p-2.5 text-right pr-3 font-black border-r-4 border-slate-400 dark:border-slate-500 text-xs uppercase tracking-wider"
                  >
                    {t.footerTotalAbsent}
                  </td>
                  {employees.map((emp) => {
                    const stats = calculateEmployeeStats(emp.empId);
                    return (
                      <td
                        key={`ft-abs-${emp.id}`}
                        colSpan={4}
                        className="p-2 text-center font-black text-sm border-r-4 border-slate-400 dark:border-slate-500 bg-slate-850 bg-[#1e293b] text-rose-300"
                      >
                        {stats.absent} {t.daysUnit}
                      </td>
                    );
                  })}
                </tr>

                {/* Total Late */}
                <tr className="bg-slate-900 text-amber-300">
                  <td
                    colSpan={2}
                    className="sticky left-0 z-40 bg-slate-900 text-amber-300 p-2.5 text-right pr-3 font-black border-r-4 border-slate-400 dark:border-slate-500 text-xs uppercase tracking-wider"
                  >
                    {t.footerTotalLate}
                  </td>
                  {employees.map((emp) => {
                    const stats = calculateEmployeeStats(emp.empId);
                    return (
                      <td
                        key={`ft-late-${emp.id}`}
                        colSpan={4}
                        className="p-2 text-center font-black text-sm border-r-4 border-slate-400 dark:border-slate-500 bg-slate-900 text-amber-300"
                      >
                        {stats.lateDays} {t.daysUnit}
                      </td>
                    );
                  })}
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* 3. CARD / GRID VIEW */}
      {viewMode === 'grid' && (
        <div className="print-area bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 shadow-xs border border-slate-200 dark:border-slate-800 transition-colors">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-6">
            <div>
              <h2 className="text-xl font-black text-[#e91e63]">
                {language === 'bn' ? 'কর্মকর্তা অনুযায়ী কার্ড সামারি' : 'Employee Attendance Cards'}
              </h2>
              <p className="text-xs font-bold text-slate-500">
                {language === 'bn' ? `মাস: ${selectedMonth}` : `Month: ${selectedMonth}`}
              </p>
            </div>
            <button
              onClick={handlePrint}
              className="no-print flex items-center gap-1.5 py-1.5 px-3 bg-pink-50 dark:bg-pink-950/40 text-[#e91e63] rounded-xl font-bold text-xs hover:bg-pink-100 transition border border-pink-200 dark:border-pink-900 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.print}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {employees.map((emp) => {
              const stats = calculateEmployeeStats(emp.empId);
              return (
                <div
                  key={emp.id}
                  className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700 shadow-xs hover:border-[#e91e63] transition group"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={emp.photoUrl || getAvatarUrl(emp.name)}
                      alt={emp.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-pink-400 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-black text-sm text-slate-900 dark:text-white truncate group-hover:text-[#e91e63]">
                        {emp.name}
                      </h3>
                      <p className="text-xs font-semibold text-slate-500 truncate">
                        {emp.empId} • {emp.designation || '-'}
                      </p>
                    </div>
                  </div>

                  {/* Attendance Stats Cards */}
                  <div className="grid grid-cols-3 gap-2 text-center mb-3">
                    <div className="bg-emerald-100 dark:bg-emerald-950/60 p-2 rounded-xl border border-emerald-200 dark:border-emerald-800">
                      <div className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300">
                        {t.presentToday}
                      </div>
                      <div className="text-base font-black text-emerald-700 dark:text-emerald-400">
                        {stats.present}
                      </div>
                    </div>

                    <div className="bg-rose-100 dark:bg-rose-950/60 p-2 rounded-xl border border-rose-200 dark:border-rose-800">
                      <div className="text-[10px] font-bold text-rose-800 dark:text-rose-300">
                        {t.absentToday}
                      </div>
                      <div className="text-base font-black text-rose-700 dark:text-rose-400">
                        {stats.absent}
                      </div>
                    </div>

                    <div className="bg-amber-100 dark:bg-amber-950/60 p-2 rounded-xl border border-amber-200 dark:border-amber-800">
                      <div className="text-[10px] font-bold text-amber-800 dark:text-amber-300">
                        {t.late}
                      </div>
                      <div className="text-base font-black text-amber-700 dark:text-amber-400">
                        {stats.lateDays}
                      </div>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div>
                    <div className="flex justify-between text-[11px] font-black mb-1">
                      <span className="text-slate-500">
                        {language === 'bn' ? 'উপস্থিতির হার' : 'Attendance Rate'}
                      </span>
                      <span className="text-[#e91e63]">{stats.attendanceRate}%</span>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-[#e91e63] h-full rounded-full transition-all duration-300"
                        style={{ width: `${stats.attendanceRate}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. LIST VIEW */}
      {viewMode === 'list' && (
        <div className="print-area bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 shadow-xs border border-slate-200 dark:border-slate-800 transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 gap-3 mb-5">
            <div>
              <h2 className="text-xl font-black text-[#e91e63]">
                {language === 'bn' ? 'দৈনিক হাজিরা লগ তালিকা' : 'Daily Attendance Log List'}
              </h2>
              <p className="text-xs font-bold text-slate-500">
                {language === 'bn' ? `মাস: ${selectedMonth}` : `Month: ${selectedMonth}`}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder={language === 'bn' ? 'কর্মকর্তা খুঁজুন...' : 'Search employee...'}
                value={searchEmployeeQuery}
                onChange={(e) => setSearchEmployeeQuery(e.target.value)}
                className="py-1.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 dark:bg-slate-800 text-xs font-bold outline-hidden focus:border-[#e91e63]"
              />
              <button
                onClick={handlePrint}
                className="no-print flex items-center gap-1.5 py-1.5 px-3 bg-pink-50 dark:bg-pink-950/40 text-[#e91e63] rounded-xl font-bold text-xs hover:bg-pink-100 transition border border-pink-200 dark:border-pink-900 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{t.print}</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-300 dark:border-slate-700">
            <table className="w-full text-left border-collapse min-w-[700px]">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs uppercase font-black">
                  <th className="p-3 border-b border-slate-300 dark:border-slate-700">{t.date}</th>
                  <th className="p-3 border-b border-slate-300 dark:border-slate-700">{t.name}</th>
                  <th className="p-3 border-b border-slate-300 dark:border-slate-700">{t.empId}</th>
                  <th className="p-3 border-b border-slate-300 dark:border-slate-700">{t.attendanceType}</th>
                  <th className="p-3 border-b border-slate-300 dark:border-slate-700">{t.time}</th>
                  <th className="p-3 border-b border-slate-300 dark:border-slate-700">{t.location}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-xs font-semibold">
                {attendance
                  .filter((a) => a.date.startsWith(selectedMonth))
                  .filter((a) => {
                    if (!searchEmployeeQuery) return true;
                    const emp = employees.find((e) => e.empId === a.empId);
                    return (
                      a.empId.toLowerCase().includes(searchEmployeeQuery.toLowerCase()) ||
                      (emp && emp.name.toLowerCase().includes(searchEmployeeQuery.toLowerCase()))
                    );
                  })
                  .slice(0, 100)
                  .map((log) => {
                    const emp = employees.find((e) => e.empId === log.empId);
                    return (
                      <tr key={log.id} className="hover:bg-pink-50/40 dark:hover:bg-pink-950/20">
                        <td className="p-3 font-bold text-slate-600 dark:text-slate-300">
                          {log.date}
                        </td>
                        <td className="p-3 font-black text-slate-900 dark:text-white">
                          {emp ? emp.name : log.empId}
                        </td>
                        <td className="p-3 font-bold text-slate-500">
                          {log.empId}
                        </td>
                        <td className="p-3">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-black text-[11px] ${
                              log.type === 'Clock IN'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                                : 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                            }`}
                          >
                            {log.type === 'Clock IN' ? (
                              <CheckCircle2 className="w-3 h-3" />
                            ) : (
                              <XCircle className="w-3 h-3" />
                            )}
                            <span>{log.type === 'Clock IN' ? t.clockIn : t.clockOut}</span>
                          </span>
                        </td>
                        <td className="p-3 font-black text-slate-800 dark:text-slate-200">
                          {log.time}
                        </td>
                        <td className="p-3">
                          {log.lat ? (
                            <a
                              href={`https://www.google.com/maps?q=${log.lat},${log.lng}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-lg border transition ${
                                log.type === 'Clock IN'
                                  ? 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100'
                                  : 'text-sky-700 dark:text-sky-300 bg-sky-50 dark:bg-sky-950/60 border-sky-300 dark:border-sky-800 hover:bg-sky-100'
                              }`}
                              title={log.locationText || `${log.lat}, ${log.lng}`}
                            >
                              <MapPin className="w-3 h-3" />
                              <span>
                                {log.type === 'Clock IN'
                                  ? (language === 'bn' ? 'প্রবেশ লোকেশন' : 'In Location')
                                  : (language === 'bn' ? 'প্রস্থান লোকেশন' : 'Out Location')}
                              </span>
                            </a>
                          ) : (
                            <span className="text-slate-400 font-normal">-</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Late Details Modal */}
      {selectedLateDetails && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-100 dark:border-slate-800 animate-fade transition-colors">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="text-lg font-black text-[#e91e63] flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <span>{t.lateDetailsTitle}</span>
              </h3>
              <button
                onClick={() => setSelectedLateDetails(null)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="mb-4">
              <div className="font-black text-slate-900 dark:text-white text-base">
                {selectedLateDetails.empName}
              </div>
              <div className="text-xs font-bold text-slate-500">
                {selectedMonth}
              </div>
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2 mb-5">
              {selectedLateDetails.records.map((r, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs font-bold"
                >
                  <span className="text-slate-800 dark:text-slate-200">{r.date}</span>
                  <span className="text-slate-600 dark:text-slate-400">{r.time}</span>
                  <span className="text-amber-700 dark:text-amber-400 font-black">
                    +{r.lateMins} {t.minutesUnit} {t.late}
                  </span>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setSelectedLateDetails(null)}
              className="w-full py-3 bg-[#e91e63] hover:bg-[#c2185b] text-white font-black rounded-xl transition shadow-sm cursor-pointer"
            >
              {t.ok}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
