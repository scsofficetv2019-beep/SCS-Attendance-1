import React from 'react';
import { Employee, AttendanceRecord } from '../types';
import { formatDateLocal } from '../utils/storage';
import { Language, translations } from '../i18n';
import {
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
} from 'lucide-react';

interface DashboardProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  language: Language;
}

export const Dashboard: React.FC<DashboardProps> = ({
  employees,
  attendance,
  language,
}) => {
  const t = translations[language];
  const todayStr = formatDateLocal(new Date());

  // Filter today's attendance logs
  const todayLogs = attendance.filter((a) => a.date === todayStr);

  // Present employees IDs (any employee who has Clock IN today)
  const presentEmpIds = new Set(
    todayLogs.filter((a) => a.type === 'Clock IN').map((a) => a.empId)
  );

  const totalEmployeesCount = employees.length;
  const presentCount = presentEmpIds.size;
  const absentCount = Math.max(0, totalEmployeesCount - presentCount);

  return (
    <div className="space-y-6 animate-fade">
      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Employees */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 shadow-xs border border-slate-100 dark:border-slate-800 flex items-center gap-4 transition-colors">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-pink-100 dark:bg-pink-950/60 text-[#e91e63] dark:text-pink-400 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {totalEmployeesCount}
            </div>
            <div className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400">
              {t.totalEmployees}
            </div>
          </div>
        </div>

        {/* Today's Total Logs */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 shadow-xs border border-slate-100 dark:border-slate-800 flex items-center gap-4 transition-colors">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
            <Clock className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {todayLogs.length}
            </div>
            <div className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400">
              {t.todayAttendance}
            </div>
          </div>
        </div>

        {/* Present Today */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 shadow-xs border border-slate-100 dark:border-slate-800 flex items-center gap-4 transition-colors">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400">
              {presentCount}
            </div>
            <div className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400">
              {t.presentToday}
            </div>
          </div>
        </div>

        {/* Absent Today */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 shadow-xs border border-slate-100 dark:border-slate-800 flex items-center gap-4 transition-colors">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
            <XCircle className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-rose-600 dark:text-rose-400">
              {absentCount}
            </div>
            <div className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400">
              {t.absentToday}
            </div>
          </div>
        </div>
      </div>

      {/* Today's Status Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-5">
          <h2 className="text-xl sm:text-2xl font-extrabold text-[#e91e63] flex items-center gap-2">
            <Calendar className="w-6 h-6" />
            <span>{t.todayStatus}</span>
          </h2>
          <span className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400">
            {todayStr}
          </span>
        </div>

        {employees.length === 0 ? (
          <div className="text-center py-12 text-slate-400 font-semibold">
            {t.noEmployees}
          </div>
        ) : (
          <div className="space-y-3">
            {employees.map((emp) => {
              const empLogs = todayLogs.filter((a) => a.empId === emp.empId);
              const clockIn = empLogs.find((a) => a.type === 'Clock IN');
              const clockOut = empLogs.find((a) => a.type === 'Clock Out');
              const isPresent = !!clockIn;

              return (
                <div
                  key={emp.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 sm:p-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-pink-200 dark:hover:border-pink-900 transition bg-slate-50/50 dark:bg-slate-800/40 gap-3"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={
                        emp.photoUrl ||
                        `https://ui-avatars.com/api/?name=${encodeURIComponent(
                          emp.name
                        )}&background=e91e63&color=fff`
                      }
                      alt={emp.name}
                      className="w-12 h-12 rounded-full object-cover border border-pink-200 shrink-0"
                    />
                    <div>
                      <div className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white">
                        {emp.name}
                      </div>
                      <div className="text-xs sm:text-sm font-semibold text-slate-500 dark:text-slate-400">
                        {emp.empId} • {emp.designation || '-'}
                      </div>
                    </div>
                  </div>

                  {/* Attendance Log Info for Today */}
                  <div className="flex items-center gap-2 sm:gap-4 self-end sm:self-center">
                    {isPresent ? (
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <div className="text-xs sm:text-sm font-bold text-emerald-600 dark:text-emerald-400">
                            {t.clockIn}: {clockIn.time}
                          </div>
                          {clockOut && (
                            <div className="text-xs sm:text-sm font-bold text-blue-600 dark:text-blue-400">
                              {t.clockOut}: {clockOut.time}
                            </div>
                          )}
                        </div>
                        <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-extrabold text-xs sm:text-sm rounded-full">
                          {language === 'bn' ? 'উপস্থিত' : 'Present'}
                        </span>
                      </div>
                    ) : (
                      <span className="px-3 py-1 bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-extrabold text-xs sm:text-sm rounded-full">
                        {language === 'bn' ? 'অনুপস্থিত' : 'Absent'}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
