import React, { useState } from 'react';
import {
  Employee,
  AttendanceRecord,
  OfficeSetup,
  DriveSetup,
} from '../types';
import {
  formatDateLocal,
  formatTime12Hour,
  formatTimeLocal,
  getAvatarUrl,
  exportAttendanceData,
} from '../utils/storage';
import { Language, translations } from '../i18n';
import {
  Users,
  CalendarCheck,
  ClipboardList,
  Building,
  HardDrive,
  Download,
  Lock,
  Plus,
  ArrowUp,
  ArrowDown,
  Edit2,
  Trash2,
  Upload,
  X,
  FileSpreadsheet,
  Printer,
  Search,
  KeyRound,
  Delete,
  CornerDownLeft,
  CheckCircle2,
} from 'lucide-react';

interface AdminPanelProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  officeSetup: OfficeSetup;
  driveSetup: DriveSetup;
  onUpdateEmployees: (emps: Employee[]) => void;
  onUpdateAttendance: (records: AttendanceRecord[]) => void;
  onUpdateOfficeSetup: (setup: OfficeSetup) => void;
  onUpdateDriveSetup: (setup: DriveSetup) => void;
  onLockAdmin: () => void;
  onShowModal: (title: string, msg: string) => void;
  onShowToast: (msg: string) => void;
  language: Language;
}

type AdminSection =
  | 'employees'
  | 'manual'
  | 'attendanceManage'
  | 'office'
  | 'drive'
  | 'export';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  employees,
  attendance,
  officeSetup,
  driveSetup,
  onUpdateEmployees,
  onUpdateAttendance,
  onUpdateOfficeSetup,
  onUpdateDriveSetup,
  onLockAdmin,
  onShowModal,
  onShowToast,
  language,
}) => {
  const t = translations[language];
  const [currentSection, setCurrentSection] = useState<AdminSection>('employees');

  // Employee Form State
  const [isEmpFormOpen, setIsEmpFormOpen] = useState(false);
  const [editingEmpId, setEditingEmpId] = useState<string | null>(null);
  const [empForm, setEmpForm] = useState({
    name: '',
    empId: '',
    designation: '',
    department: '',
    mobile: '',
    photoUrl: '',
  });

  // Manual Attendance State
  const [manualEmpId, setManualEmpId] = useState('');
  const [manualType, setManualType] = useState<'Clock IN' | 'Clock Out'>('Clock IN');
  const [manualDate, setManualDate] = useState(formatDateLocal(new Date()));
  const [manualTime, setManualTime] = useState(formatTimeLocal(new Date()));
  const [manualNote, setManualNote] = useState('');

  // Attendance Manage State
  const [sheetMonth, setSheetMonth] = useState(
    `${new Date().getFullYear()}-${('0' + (new Date().getMonth() + 1)).slice(-2)}`
  );
  const [sheetDay, setSheetDay] = useState('');
  const [editingAttendance, setEditingAttendance] = useState<AttendanceRecord | null>(null);

  // Office Setup State
  const [officeForm, setOfficeForm] = useState<OfficeSetup>({ ...officeSetup });
  const [holidayPicker, setHolidayPicker] = useState('');

  // Drive Setup State
  const [driveForm, setDriveForm] = useState<DriveSetup>({ ...driveSetup });

  // Export State
  const [exportType, setExportType] = useState<'single' | 'multiple' | '1year' | '2year'>('single');
  const [exportSingleMonth, setExportSingleMonth] = useState(sheetMonth);
  const [exportMonths, setExportMonths] = useState<string[]>([sheetMonth]);
  const [exportYear, setExportYear] = useState(new Date().getFullYear());
  const [exportResult, setExportResult] = useState<{
    csvUrl: string;
    printableHtml: string;
  } | null>(null);

  // Admin PIN verification for Edit and Delete operations
  const [pinPromptAction, setPinPromptAction] = useState<
    | { type: 'edit'; emp: Employee }
    | { type: 'delete'; empId: string }
    | null
  >(null);
  const [adminActionPin, setAdminActionPin] = useState('');
  const [adminActionPinError, setAdminActionPinError] = useState('');

  // Manual Attendance Employee Search Modal
  const [isManualSearchModalOpen, setIsManualSearchModalOpen] = useState(false);
  const [manualSearchQuery, setManualSearchQuery] = useState('');

  const handleRequestEditEmp = (emp: Employee) => {
    setAdminActionPin('');
    setAdminActionPinError('');
    setPinPromptAction({ type: 'edit', emp });
  };

  const handleRequestDeleteEmp = (empId: string) => {
    setAdminActionPin('');
    setAdminActionPinError('');
    setPinPromptAction({ type: 'delete', empId });
  };

  const handleConfirmPinAction = () => {
    if (adminActionPin !== '2026') {
      setAdminActionPinError(language === 'bn' ? 'ভুল এডমিন পিন!' : 'Incorrect Admin PIN!');
      setAdminActionPin('');
      return;
    }

    if (!pinPromptAction) return;

    if (pinPromptAction.type === 'edit') {
      const empToEdit = pinPromptAction.emp;
      setPinPromptAction(null);
      handleOpenEmpForm(empToEdit);
    } else if (pinPromptAction.type === 'delete') {
      const idToDelete = pinPromptAction.empId;
      const updated = employees.filter((e) => e.id !== idToDelete);
      onUpdateEmployees(updated);
      setPinPromptAction(null);
      onShowToast(language === 'bn' ? 'কর্মকর্তা মুছে ফেলা হয়েছে' : 'Employee deleted successfully');
    }
  };

  /* EMPLOYEE MANAGEMENT */
  const handleOpenEmpForm = (emp?: Employee) => {
    if (emp) {
      setEditingEmpId(emp.id);
      setEmpForm({
        name: emp.name,
        empId: emp.empId,
        designation: emp.designation,
        department: emp.department,
        mobile: emp.mobile,
        photoUrl: emp.photoUrl,
      });
    } else {
      setEditingEmpId(null);
      setEmpForm({
        name: '',
        empId: `SCS-${100 + employees.length + 1}`,
        designation: '',
        department: '',
        mobile: '',
        photoUrl: '',
      });
    }
    setIsEmpFormOpen(true);
  };

  const handleSaveEmployee = () => {
    if (!empForm.name.trim() || !empForm.empId.trim()) {
      onShowModal(
        language === 'bn' ? 'তথ্য পূরণ করুন' : 'Fill required fields',
        language === 'bn' ? 'কর্মকর্তার নাম এবং আইডি পূরণ করা আবশ্যক।' : 'Name and ID are required.'
      );
      return;
    }

    if (editingEmpId) {
      const updated = employees.map((e) =>
        e.id === editingEmpId ? { ...e, ...empForm } : e
      );
      onUpdateEmployees(updated);
      onShowToast(language === 'bn' ? 'কর্মকর্তার তথ্য আপডেট করা হয়েছে' : 'Employee details updated');
    } else {
      const newEmp: Employee = {
        id: `emp-${Date.now()}`,
        ...empForm,
        created: new Date().toISOString(),
        sortOrder: employees.length + 1,
      };
      onUpdateEmployees([...employees, newEmp]);
      onShowToast(language === 'bn' ? 'নতুন কর্মকর্তা সফলভাবে যুক্ত করা হয়েছে' : 'New employee added successfully');
    }
    setIsEmpFormOpen(false);
  };

  const handleMoveEmp = (id: string, direction: 'up' | 'down') => {
    const list = [...employees];
    const index = list.findIndex((e) => e.id === id);
    if (index === -1) return;

    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= list.length) return;

    const temp = list[index];
    list[index] = list[targetIndex];
    list[targetIndex] = temp;

    const updated = list.map((e, idx) => ({ ...e, sortOrder: idx + 1 }));
    onUpdateEmployees(updated);
    onShowToast(language === 'bn' ? 'ক্রম পরিবর্তন সম্পন্ন হয়েছে' : 'Order updated');
  };

  const handleDeleteEmployee = (id: string) => {
    const emp = employees.find((e) => e.id === id);
    if (!emp) return;

    if (window.confirm(t.deleteEmployeeConfirm)) {
      const updated = employees.filter((e) => e.id !== id);
      onUpdateEmployees(updated);
      onShowToast(language === 'bn' ? 'কর্মকর্তা মুছে ফেলা হয়েছে' : 'Employee deleted');
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    onShowToast(language === 'bn' ? 'ছবি প্রসেস করা হচ্ছে...' : 'Processing image...');
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result as string;
      if (result) {
        setEmpForm((prev) => ({ ...prev, photoUrl: result }));
        onShowToast(language === 'bn' ? 'ছবি সফলভাবে লোড হয়েছে' : 'Photo loaded successfully');
      }
    };
    reader.readAsDataURL(file);
  };

  /* MANUAL ATTENDANCE */
  const handleSaveManual = () => {
    if (!manualEmpId) {
      onShowModal(
        language === 'bn' ? 'কর্মকর্তা নির্বাচন' : 'Select Employee',
        language === 'bn' ? 'অনুগ্রহ করে কর্মকর্তা নির্বাচন করুন।' : 'Please choose an employee first.'
      );
      return;
    }

    const newRecord: AttendanceRecord = {
      id: `att-manual-${Date.now()}`,
      empId: manualEmpId,
      date: manualDate,
      type: manualType,
      time: formatTime12Hour(manualTime),
      lat: 23.8103,
      lng: 90.4125,
      locationText: 'Manual Entry (Admin)',
      note: manualNote,
      createdBy: 'admin',
    };

    onUpdateAttendance([newRecord, ...attendance]);
    onShowToast(language === 'bn' ? 'হাতেকলমে হাজিরা সংরক্ষণ সম্পন্ন!' : 'Manual attendance record saved!');
    setManualNote('');
  };

  /* ATTENDANCE MANAGE */
  const filteredRecords = attendance
    .filter((r) => {
      if (sheetDay) return r.date === sheetDay;
      if (sheetMonth) return r.date.startsWith(sheetMonth);
      return true;
    })
    .sort((a, b) => (a.date + a.time > b.date + b.time ? -1 : 1));

  const handleSaveEditAttendance = () => {
    if (!editingAttendance) return;
    const updated = attendance.map((a) =>
      a.id === editingAttendance.id
        ? {
            ...editingAttendance,
            time: formatTime12Hour(editingAttendance.time),
          }
        : a
    );
    onUpdateAttendance(updated);
    setEditingAttendance(null);
    onShowToast(language === 'bn' ? 'হাজিরা রেকর্ড আপডেট করা হয়েছে' : 'Attendance record updated');
  };

  const handleDeleteAttendance = (id: string) => {
    if (window.confirm(language === 'bn' ? 'আপনি কি নিশ্চিতভাবে এই রেকর্ড মুছে ফেলতে চান?' : 'Are you sure you want to delete this record?')) {
      const updated = attendance.filter((a) => a.id !== id);
      onUpdateAttendance(updated);
      onShowToast(language === 'bn' ? 'রেকর্ড মুছে ফেলা হয়েছে' : 'Record deleted');
    }
  };

  /* OFFICE SETUP */
  const handleAddHoliday = () => {
    if (!holidayPicker) return;
    const d = new Date(holidayPicker);
    const dayNamesEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayNamesBn = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
    const dayName = language === 'bn' ? dayNamesBn[d.getDay()] : dayNamesEn[d.getDay()];
    const label = `${holidayPicker} (${dayName})`;
    if (!officeForm.holidays.includes(label)) {
      setOfficeForm((prev) => ({
        ...prev,
        holidays: [...prev.holidays, label],
      }));
    }
    setHolidayPicker('');
  };

  const handleRemoveHoliday = (idx: number) => {
    setOfficeForm((prev) => ({
      ...prev,
      holidays: prev.holidays.filter((_, i) => i !== idx),
    }));
  };

  const handleSaveOffice = () => {
    onUpdateOfficeSetup(officeForm);
    onShowToast(language === 'bn' ? 'অফিস সময় ও ছুটির নিয়মাবলী সংরক্ষিত হয়েছে' : 'Office setup saved successfully');
  };

  /* DRIVE SETUP */
  const handleSaveDrive = () => {
    onUpdateDriveSetup(driveForm);
    onShowToast(language === 'bn' ? 'গুগল ড্রাইভ সংযোগ সংরক্ষিত হয়েছে' : 'Google Drive setup saved');
  };

  /* EXPORT */
  const handleExport = () => {
    const months = exportType === 'single' ? [exportSingleMonth] : exportMonths;
    const result = exportAttendanceData(
      { type: exportType, months, year: exportYear },
      employees,
      attendance,
      officeSetup
    );
    setExportResult(result);
    onShowToast(language === 'bn' ? 'এক্সপোর্ট ফাইল প্রস্তুত!' : 'Export file ready!');
  };

  const selectedManualEmp = employees.find((e) => e.empId === manualEmpId);

  return (
    <div className="space-y-6 animate-fade">
      {/* Admin Submenu Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-2 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap gap-2 items-center justify-between no-print transition-colors">
        <div className="flex flex-wrap gap-1.5 sm:gap-2 flex-1">
          <button
            onClick={() => setCurrentSection('employees')}
            className={`py-2 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition ${
              currentSection === 'employees'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>{t.employeesTab}</span>
          </button>

          <button
            onClick={() => setCurrentSection('manual')}
            className={`py-2 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition ${
              currentSection === 'manual'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <CalendarCheck className="w-4 h-4" />
            <span>{t.manualTab}</span>
          </button>

          <button
            onClick={() => setCurrentSection('attendanceManage')}
            className={`py-2 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition ${
              currentSection === 'attendanceManage'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <ClipboardList className="w-4 h-4" />
            <span>{t.attendanceManageTab}</span>
          </button>

          <button
            onClick={() => setCurrentSection('office')}
            className={`py-2 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition ${
              currentSection === 'office'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>{t.officeTab}</span>
          </button>

          <button
            onClick={() => setCurrentSection('drive')}
            className={`py-2 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition ${
              currentSection === 'drive'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <HardDrive className="w-4 h-4" />
            <span>{t.driveTab}</span>
          </button>

          <button
            onClick={() => setCurrentSection('export')}
            className={`py-2 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition ${
              currentSection === 'export'
                ? 'bg-[#e91e63] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>{t.exportTab}</span>
          </button>
        </div>

        <button
          onClick={onLockAdmin}
          className="py-2 px-3.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs sm:text-sm hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 transition"
        >
          <Lock className="w-4 h-4 text-rose-500" />
          <span>{t.lock}</span>
        </button>
      </div>

      {/* 1. EMPLOYEES SECTION */}
      {currentSection === 'employees' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63]">
                {t.employeeList}
              </h3>
              <button
                type="button"
                onClick={() => handleOpenEmpForm()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#e91e63] text-white font-bold text-sm sm:text-base hover:bg-[#c2185b] transition shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{t.addEmployee}</span>
              </button>
            </div>

            {/* List */}
            <div className="space-y-3">
              {employees.map((emp, idx) => (
                <div
                  key={emp.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 sm:p-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 hover:border-pink-200 dark:hover:border-pink-900 transition bg-white dark:bg-slate-850 gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-7 text-center font-extrabold text-[#e91e63] text-lg shrink-0">
                      {idx + 1}
                    </span>
                    <img
                      src={emp.photoUrl || getAvatarUrl(emp.name)}
                      alt={emp.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-pink-200 dark:border-pink-900 shrink-0"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = getAvatarUrl(emp.name);
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white truncate">
                        {emp.name}
                      </div>
                      <div className="text-xs sm:text-sm font-semibold text-slate-500 dark:text-slate-400 truncate">
                        {emp.empId} • {emp.designation || '-'} • {emp.mobile || '-'}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 self-end sm:self-center">
                    <button
                      onClick={() => handleMoveEmp(emp.id, 'up')}
                      disabled={idx === 0}
                      className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 transition"
                    >
                      <ArrowUp className="w-4 h-4 text-slate-700 dark:text-slate-300" />
                    </button>
                    <button
                      onClick={() => handleMoveEmp(emp.id, 'down')}
                      disabled={idx === employees.length - 1}
                      className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 transition"
                    >
                      <ArrowDown className="w-4 h-4 text-slate-700 dark:text-slate-300" />
                    </button>
                    <button
                      onClick={() => handleRequestEditEmp(emp)}
                      className="px-3 py-1.5 rounded-xl border border-[#e91e63] text-[#e91e63] hover:bg-pink-50 dark:hover:bg-pink-950/40 text-xs sm:text-sm font-bold flex items-center gap-1 transition cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>{t.edit}</span>
                    </button>
                    <button
                      onClick={() => handleRequestDeleteEmp(emp.id)}
                      className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 text-xs sm:text-sm font-bold flex items-center gap-1 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t.del}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Add/Edit Modal */}
          {isEmpFormOpen && (
            <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs">
              <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-100 dark:border-slate-800 max-h-[90vh] overflow-y-auto animate-fade transition-colors">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
                  <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63]">
                    {editingEmpId ? t.editEmployee : t.addEmployee}
                  </h3>
                  <button
                    onClick={() => setIsEmpFormOpen(false)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.fullName} *
                    </label>
                    <input
                      type="text"
                      value={empForm.name}
                      onChange={(e) => setEmpForm({ ...empForm, name: e.target.value })}
                      placeholder="e.g. Rafiqul Islam"
                      className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.empId} *
                    </label>
                    <input
                      type="text"
                      value={empForm.empId}
                      onChange={(e) => setEmpForm({ ...empForm, empId: e.target.value })}
                      placeholder="e.g. SCS-106"
                      className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.designation}
                    </label>
                    <input
                      type="text"
                      value={empForm.designation}
                      onChange={(e) => setEmpForm({ ...empForm, designation: e.target.value })}
                      placeholder="e.g. Field Supervisor"
                      className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.department}
                    </label>
                    <input
                      type="text"
                      value={empForm.department}
                      onChange={(e) => setEmpForm({ ...empForm, department: e.target.value })}
                      placeholder="e.g. Operations"
                      className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.mobile}
                    </label>
                    <input
                      type="tel"
                      value={empForm.mobile}
                      onChange={(e) => setEmpForm({ ...empForm, mobile: e.target.value })}
                      placeholder="e.g. 01711000001"
                      className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.photoUrl}
                    </label>
                    <input
                      type="text"
                      value={empForm.photoUrl}
                      onChange={(e) => setEmpForm({ ...empForm, photoUrl: e.target.value })}
                      placeholder="https://..."
                      className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
                    />
                  </div>

                  <div className="bg-pink-50/50 dark:bg-pink-950/20 p-4 rounded-2xl border border-pink-200 dark:border-pink-900">
                    <label className="block text-xs sm:text-sm font-bold text-[#e91e63] dark:text-pink-400 mb-1 flex items-center gap-1.5">
                      <Upload className="w-4 h-4" />
                      <span>{t.uploadDevicePhoto}:</span>
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="text-sm font-semibold file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-[#e91e63] file:text-white hover:file:bg-[#c2185b] cursor-pointer"
                    />
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    type="button"
                    onClick={handleSaveEmployee}
                    className="flex-1 py-3.5 rounded-xl bg-[#e91e63] text-white font-extrabold hover:bg-[#c2185b] transition shadow-md"
                  >
                    {t.saveEmployee}
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEmpFormOpen(false)}
                    className="px-5 py-3.5 rounded-xl border-2 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    {t.cancel}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. MANUAL ATTENDANCE SECTION */}
      {currentSection === 'manual' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-7 shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63] mb-5">
            {t.manualAttendanceTitle}
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                {t.selectEmployeePrompt}
              </label>

              {/* Round Ring & Search Trigger */}
              <div className="flex flex-col items-center justify-center p-4 rounded-3xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 text-center">
                <div
                  onClick={() => {
                    setManualSearchQuery('');
                    setIsManualSearchModalOpen(true);
                  }}
                  className="group cursor-pointer flex flex-col items-center"
                >
                  <div
                    className={`w-24 h-24 rounded-full border-4 ${
                      selectedManualEmp
                        ? 'border-[#e91e63] shadow-md shadow-pink-500/20'
                        : 'border-dashed border-[#e91e63] bg-pink-50/60 dark:bg-pink-950/30'
                    } p-1 bg-white dark:bg-slate-800 flex items-center justify-center transition-transform group-hover:scale-105`}
                  >
                    {selectedManualEmp ? (
                      <img
                        src={selectedManualEmp.photoUrl || getAvatarUrl(selectedManualEmp.name)}
                        alt={selectedManualEmp.name}
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <div className="text-[#e91e63] dark:text-pink-400 text-center p-2">
                        <Search className="w-6 h-6 mx-auto mb-1" />
                        <span className="text-[10px] font-black">{language === 'bn' ? 'খুঁজুন' : 'Search'}</span>
                      </div>
                    )}
                  </div>

                  {selectedManualEmp ? (
                    <div className="mt-2">
                      <div className="font-black text-base text-slate-900 dark:text-white">
                        {selectedManualEmp.name}
                      </div>
                      <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-0.5">
                        {selectedManualEmp.empId} • {selectedManualEmp.designation || '-'}
                      </div>
                      <span className="inline-block mt-1 text-[11px] font-bold text-[#e91e63] underline">
                        {language === 'bn' ? 'পরিবর্তন করতে চাপ দিন' : 'Tap to change'}
                      </span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setManualSearchQuery('');
                        setIsManualSearchModalOpen(true);
                      }}
                      className="mt-2 px-4 py-2 rounded-xl bg-[#e91e63] text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'কর্মকর্তা খুঁজুন ও নির্বাচন করুন' : 'Search & Select Employee'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.attendanceType}
              </label>
              <select
                value={manualType}
                onChange={(e) => setManualType(e.target.value as any)}
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
              >
                <option value="Clock IN">{t.clockIn}</option>
                <option value="Clock Out">{t.clockOut}</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.date}
                </label>
                <input
                  type="date"
                  value={manualDate}
                  onChange={(e) => setManualDate(e.target.value)}
                  className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.time}
                </label>
                <input
                  type="time"
                  value={manualTime}
                  onChange={(e) => setManualTime(e.target.value)}
                  className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.reasonOrNote}
              </label>
              <textarea
                value={manualNote}
                onChange={(e) => setManualNote(e.target.value)}
                placeholder="..."
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-medium outline-hidden focus:border-[#e91e63] min-h-[90px]"
              />
            </div>

            <button
              type="button"
              onClick={handleSaveManual}
              className="w-full py-4 rounded-xl bg-[#e91e63] text-white font-extrabold text-base hover:bg-[#c2185b] transition shadow-md"
            >
              {t.saveManualAttendance}
            </button>
          </div>
        </div>
      )}

      {/* 3. ATTENDANCE MANAGE SECTION */}
      {currentSection === 'attendanceManage' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
            <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63] mb-4">
              {t.attendanceManageTab}
            </h3>

            {/* Filter Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {t.month}
                </label>
                <input
                  type="month"
                  value={sheetMonth}
                  onChange={(e) => {
                    setSheetMonth(e.target.value);
                    setSheetDay('');
                  }}
                  className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {t.filterSpecificDay}
                </label>
                <input
                  type="date"
                  value={sheetDay}
                  onChange={(e) => setSheetDay(e.target.value)}
                  className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                />
              </div>
            </div>

            {/* Records List */}
            <div className="space-y-3">
              {filteredRecords.length === 0 ? (
                <div className="text-center py-10 text-slate-400 font-bold">
                  {language === 'bn' ? 'কোনো রেকর্ড পাওয়া যায়নি' : 'No records found'}
                </div>
              ) : (
                filteredRecords.map((r) => {
                  const emp = employees.find((e) => e.empId === r.empId);
                  return (
                    <div
                      key={r.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-2xl border-2 border-slate-100 dark:border-slate-800 hover:border-pink-200 dark:hover:border-pink-900 transition bg-white dark:bg-slate-850 gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={emp?.photoUrl || getAvatarUrl(emp?.name || r.empId)}
                          alt={emp?.name || r.empId}
                          className="w-12 h-12 rounded-full object-cover border border-pink-200 shrink-0"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = getAvatarUrl(emp?.name || r.empId);
                          }}
                        />
                        <div className="min-w-0">
                          <div className="font-extrabold text-base text-slate-900 dark:text-white truncate">
                            {emp?.name || r.empId}
                          </div>
                          <div className="text-xs sm:text-sm font-semibold text-slate-500 dark:text-slate-400">
                            {r.date} •{' '}
                            <span
                              className={
                                r.type === 'Clock IN' ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-blue-600 dark:text-blue-400 font-bold'
                              }
                            >
                              {r.type === 'Clock IN' ? t.clockIn : t.clockOut}
                            </span>{' '}
                            • {r.time}
                            {r.note && ` (${r.note})`}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <button
                          onClick={() => setEditingAttendance(r)}
                          className="px-3 py-1.5 rounded-xl border border-[#e91e63] text-[#e91e63] hover:bg-pink-50 dark:hover:bg-pink-950/40 text-xs sm:text-sm font-bold flex items-center gap-1 transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>{t.edit}</span>
                        </button>
                        <button
                          onClick={() => handleDeleteAttendance(r.id)}
                          className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 text-xs sm:text-sm font-bold flex items-center gap-1 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{t.del}</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Edit Attendance Modal */}
          {editingAttendance && (
            <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs">
              <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-100 dark:border-slate-800 animate-fade transition-colors">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
                  <h3 className="text-xl font-extrabold text-[#e91e63]">
                    {language === 'bn' ? 'হাজিরা এডিট করুন' : 'Edit Attendance Record'}
                  </h3>
                  <button
                    onClick={() => setEditingAttendance(null)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.attendanceType}
                    </label>
                    <select
                      value={editingAttendance.type}
                      onChange={(e) =>
                        setEditingAttendance({
                          ...editingAttendance,
                          type: e.target.value as any,
                        })
                      }
                      className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                    >
                      <option value="Clock IN">{t.clockIn}</option>
                      <option value="Clock Out">{t.clockOut}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.date}
                    </label>
                    <input
                      type="date"
                      value={editingAttendance.date}
                      onChange={(e) =>
                        setEditingAttendance({
                          ...editingAttendance,
                          date: e.target.value,
                        })
                      }
                      className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.time}
                    </label>
                    <input
                      type="text"
                      value={editingAttendance.time}
                      onChange={(e) =>
                        setEditingAttendance({
                          ...editingAttendance,
                          time: e.target.value,
                        })
                      }
                      placeholder="e.g. 09:15 AM"
                      className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {t.reasonOrNote}
                    </label>
                    <textarea
                      value={editingAttendance.note || ''}
                      onChange={(e) =>
                        setEditingAttendance({
                          ...editingAttendance,
                          note: e.target.value,
                        })
                      }
                      className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-medium min-h-[80px]"
                    />
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    type="button"
                    onClick={handleSaveEditAttendance}
                    className="flex-1 py-3.5 rounded-xl bg-[#e91e63] text-white font-extrabold hover:bg-[#c2185b] transition shadow-md"
                  >
                    {t.saveChanges}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingAttendance(null)}
                    className="px-5 py-3.5 rounded-xl border-2 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    {t.cancel}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. OFFICE SETUP SECTION */}
      {currentSection === 'office' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-7 shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63] mb-5">
            {t.officeSetupTitle}
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.officeInTime}
              </label>
              <input
                type="time"
                value={officeForm.officeInTime}
                onChange={(e) =>
                  setOfficeForm({ ...officeForm, officeInTime: e.target.value })
                }
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.officeOutTime}
              </label>
              <input
                type="time"
                value={officeForm.officeOutTime}
                onChange={(e) =>
                  setOfficeForm({ ...officeForm, officeOutTime: e.target.value })
                }
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.maxLateGrace}
              </label>
              <input
                type="number"
                value={officeForm.maxLateMinutes}
                onChange={(e) =>
                  setOfficeForm({ ...officeForm, maxLateMinutes: e.target.value })
                }
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.holidaysSetup}
              </label>

              {/* Chips */}
              <div className="flex flex-wrap gap-2 mb-3">
                {officeForm.holidays.length === 0 ? (
                  <span className="text-sm text-slate-400 font-semibold">
                    {language === 'bn' ? 'কোন ছুটি যোগ করা হয়নি' : 'No holidays added yet'}
                  </span>
                ) : (
                  officeForm.holidays.map((h, i) => (
                    <div
                      key={i}
                      className="bg-pink-100 dark:bg-pink-950/60 text-[#c2185b] dark:text-pink-300 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold flex items-center gap-1.5"
                    >
                      <span>{h}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveHoliday(i)}
                        className="text-base font-black hover:text-rose-700 cursor-pointer ml-1"
                      >
                        ×
                      </button>
                    </div>
                  ))
                )}
              </div>

              {/* Add Picker */}
              <div className="flex gap-2">
                <input
                  type="date"
                  value={holidayPicker}
                  onChange={(e) => setHolidayPicker(e.target.value)}
                  className="flex-1 p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                />
                <button
                  type="button"
                  onClick={handleAddHoliday}
                  className="px-4 py-3 bg-[#e91e63] text-white font-bold rounded-xl hover:bg-[#c2185b] transition flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.addHoliday}</span>
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={handleSaveOffice}
              className="w-full py-4 rounded-xl bg-[#e91e63] text-white font-extrabold text-base hover:bg-[#c2185b] transition shadow-md mt-4"
            >
              {t.saveOfficeSetup}
            </button>
          </div>
        </div>
      )}

      {/* 5. DRIVE SETUP SECTION */}
      {currentSection === 'drive' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-7 shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63] mb-5">
            {t.driveSetupTitle}
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.driveFolderId}
              </label>
              <input
                type="text"
                value={driveForm.folderId}
                onChange={(e) =>
                  setDriveForm({ ...driveForm, folderId: e.target.value })
                }
                placeholder="1AbCdEfGhIjKlMnOpQrStUvWxYz"
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.driveFolderUrl}
              </label>
              <input
                type="text"
                value={driveForm.folderUrl}
                onChange={(e) =>
                  setDriveForm({ ...driveForm, folderUrl: e.target.value })
                }
                placeholder="https://drive.google.com/drive/folders/..."
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-semibold outline-hidden focus:border-[#e91e63]"
              />
            </div>

            <button
              type="button"
              onClick={handleSaveDrive}
              className="w-full py-4 rounded-xl bg-[#e91e63] text-white font-extrabold text-base hover:bg-[#c2185b] transition shadow-md mt-2"
            >
              {t.saveDriveSetup}
            </button>
          </div>
        </div>
      )}

      {/* 6. EXPORT SECTION */}
      {currentSection === 'export' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-7 shadow-sm border border-slate-100 dark:border-slate-800 transition-colors">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#e91e63] mb-5">
            {t.exportAttendanceTitle}
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.exportSelection}
              </label>
              <select
                value={exportType}
                onChange={(e) => {
                  setExportType(e.target.value as any);
                  setExportResult(null);
                }}
                className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
              >
                <option value="single">{t.singleMonth}</option>
                <option value="multiple">{t.multipleMonths}</option>
                <option value="1year">{t.oneYear}</option>
                <option value="2year">{t.twoYears}</option>
              </select>
            </div>

            {exportType === 'single' && (
              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.month}
                </label>
                <input
                  type="month"
                  value={exportSingleMonth}
                  onChange={(e) => setExportSingleMonth(e.target.value)}
                  className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
                />
              </div>
            )}

            {exportType === 'multiple' && (
              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.multipleMonths}
                </label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {exportMonths.map((m, i) => (
                    <div
                      key={i}
                      className="bg-pink-100 dark:bg-pink-950/60 text-[#c2185b] dark:text-pink-300 px-3.5 py-1.5 rounded-full text-sm font-bold flex items-center gap-1.5"
                    >
                      <span>{m}</span>
                      <button
                        type="button"
                        onClick={() =>
                          setExportMonths(exportMonths.filter((_, idx) => idx !== i))
                        }
                        className="font-bold hover:text-rose-700 cursor-pointer ml-1"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
                <input
                  type="month"
                  onChange={(e) => {
                    if (e.target.value && !exportMonths.includes(e.target.value)) {
                      setExportMonths([...exportMonths, e.target.value]);
                    }
                  }}
                  className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                />
              </div>
            )}

            {(exportType === '1year' || exportType === '2year') && (
              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {language === 'bn' ? 'শুরুর সাল' : 'Start Year'}
                </label>
                <input
                  type="number"
                  value={exportYear}
                  onChange={(e) => setExportYear(parseInt(e.target.value, 10) || 2026)}
                  className="w-full p-3.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-base font-bold outline-hidden focus:border-[#e91e63]"
                />
              </div>
            )}

            <button
              type="button"
              onClick={handleExport}
              className="w-full py-4 rounded-xl bg-[#e91e63] text-white font-extrabold text-base hover:bg-[#c2185b] transition shadow-md flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              <span>{t.exportPdfAndCsv}</span>
            </button>

            {exportResult && (
              <div className="mt-4 p-4 rounded-2xl bg-pink-50 dark:bg-pink-950/40 border border-pink-200 dark:border-pink-900 space-y-3">
                <a
                  href={exportResult.csvUrl}
                  download={`attendance_export_${Date.now()}.csv`}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-center block transition shadow-xs flex items-center justify-center gap-2"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>{t.downloadCsv}</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    const win = window.open('', '_blank');
                    if (win) {
                      win.document.write(exportResult.printableHtml);
                      win.document.close();
                    }
                  }}
                  className="w-full py-3 bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 text-white font-extrabold rounded-xl text-center block transition shadow-xs flex items-center justify-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  <span>{t.viewPdf}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Manual Attendance Employee Search Modal */}
      {isManualSearchModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl border border-slate-100 dark:border-slate-800 max-h-[85vh] flex flex-col animate-fade transition-colors">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-3">
              <h3 className="text-base font-extrabold text-[#e91e63]">
                {t.selectEmployeeModalTitle}
              </h3>
              <button
                onClick={() => setIsManualSearchModalOpen(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Search Input */}
            <div className="relative mb-3">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={t.searchEmployeePlaceholder}
                value={manualSearchQuery}
                onChange={(e) => setManualSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-sm font-semibold outline-hidden focus:border-[#e91e63]"
                autoFocus
              />
            </div>

            {/* Employee List */}
            <div className="overflow-y-auto flex-1 space-y-2 pr-1">
              {employees
                .filter(
                  (e) =>
                    e.name.toLowerCase().includes(manualSearchQuery.toLowerCase()) ||
                    e.empId.toLowerCase().includes(manualSearchQuery.toLowerCase())
                )
                .map((emp) => (
                  <div
                    key={emp.id}
                    onClick={() => {
                      setManualEmpId(emp.empId);
                      setIsManualSearchModalOpen(false);
                    }}
                    className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-pink-50 dark:hover:bg-pink-950/40 border border-slate-100 dark:border-slate-800 cursor-pointer transition group"
                  >
                    <img
                      src={emp.photoUrl || getAvatarUrl(emp.name)}
                      alt={emp.name}
                      className="w-11 h-11 rounded-full object-cover border-2 border-pink-400 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-sm text-slate-900 dark:text-white group-hover:text-[#e91e63] truncate">
                        {emp.name}
                      </div>
                      <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 truncate">
                        {emp.empId} • {emp.designation || '-'}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* Admin PIN Verification Modal for Edit & Delete */}
      {pinPromptAction && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 text-center shadow-2xl border border-slate-100 dark:border-slate-800 animate-fade transition-colors">
            <div className="w-14 h-14 mx-auto mb-3 bg-pink-100 dark:bg-pink-950/60 text-[#e91e63] rounded-2xl flex items-center justify-center shadow-xs">
              <KeyRound className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-black text-slate-900 dark:text-white mb-1">
              {language === 'bn' ? 'এডমিন পিন যাচাই' : 'Verify Admin PIN'}
            </h3>
            <p className="text-xs font-bold text-slate-500 mb-4">
              {pinPromptAction.type === 'edit'
                ? (language === 'bn' ? 'কর্মকর্তা এডিট করতে এডমিন পিন দিন' : 'Enter Admin PIN to edit employee')
                : (language === 'bn' ? 'কর্মকর্তা ডিলিট করতে এডমিন পিন দিন' : 'Enter Admin PIN to delete employee')}
            </p>

            {/* PIN Dots */}
            <div className="flex justify-center items-center gap-3 mb-4">
              {[0, 1, 2, 3].map((index) => (
                <div
                  key={index}
                  className={`w-3.5 h-3.5 rounded-full transition-all ${
                    index < adminActionPin.length
                      ? 'bg-[#e91e63] scale-125 shadow-md shadow-pink-400/50'
                      : 'bg-slate-200 dark:bg-slate-700'
                  }`}
                />
              ))}
            </div>

            {adminActionPinError && (
              <p className="text-xs font-black text-rose-500 mb-3">
                {adminActionPinError}
              </p>
            )}

            {/* Keypad */}
            <div className="grid grid-cols-3 gap-2 mb-3">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => {
                    if (adminActionPin.length < 4) {
                      const next = adminActionPin + digit;
                      setAdminActionPin(next);
                      setAdminActionPinError('');
                    }
                  }}
                  className="h-11 text-lg font-black text-slate-800 dark:text-white bg-slate-50 dark:bg-slate-800 hover:bg-pink-50 dark:hover:bg-pink-950/40 rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center cursor-pointer"
                >
                  {digit}
                </button>
              ))}

              <button
                type="button"
                onClick={() => setAdminActionPin('')}
                className="h-11 text-xs font-bold text-rose-500 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 rounded-xl border border-rose-100 dark:border-rose-900 flex items-center justify-center cursor-pointer"
              >
                {t.clear}
              </button>

              <button
                type="button"
                onClick={() => {
                  if (adminActionPin.length < 4) {
                    const next = adminActionPin + '0';
                    setAdminActionPin(next);
                    setAdminActionPinError('');
                  }
                }}
                className="h-11 text-lg font-black text-slate-800 dark:text-white bg-slate-50 dark:bg-slate-800 hover:bg-pink-50 dark:hover:bg-pink-950/40 rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center cursor-pointer"
              >
                0
              </button>

              <button
                type="button"
                onClick={() => setAdminActionPin((prev) => prev.slice(0, -1))}
                className="h-11 text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer"
              >
                <Delete className="w-5 h-5" />
              </button>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setPinPromptAction(null);
                  setAdminActionPin('');
                  setAdminActionPinError('');
                }}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs hover:bg-slate-100 cursor-pointer"
              >
                {t.cancel}
              </button>

              <button
                type="button"
                onClick={handleConfirmPinAction}
                disabled={adminActionPin.length === 0}
                className="flex-1 py-2.5 rounded-xl bg-[#e91e63] hover:bg-[#c2185b] text-white font-black text-xs transition disabled:opacity-40 cursor-pointer shadow-xs"
              >
                {language === 'bn' ? 'যাচাই করুন' : 'Verify'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
