import React from 'react';
import {
  LayoutDashboard,
  CalendarCheck,
  CalendarDays,
  ShieldCheck,
  RefreshCw,
  LogOut,
  Sun,
  Moon,
  Globe,
} from 'lucide-react';
import { Language, Theme, translations } from '../i18n';

export type NavTab = 'dashboard' | 'attendance' | 'leave' | 'admin';

interface TopNavProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  onSync: () => void;
  onLogout: () => void;
  isSyncing: boolean;
  language: Language;
  theme: Theme;
  onToggleLanguage: () => void;
  onToggleTheme: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  onTabChange,
  onSync,
  onLogout,
  isSyncing,
  language,
  theme,
  onToggleLanguage,
  onToggleTheme,
}) => {
  const t = translations[language];

  return (
    <div className="no-print">
      {/* 1. TOP BAR (Pink Background Layer) */}
      <header className="bg-[#e91e63] dark:bg-[#880e4f] text-white shadow-xs sticky top-0 z-40 transition-colors">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-14 sm:h-16 gap-3">
            {/* App Brand & Title (Clean & Simple) */}
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-white text-[#e91e63] flex items-center justify-center font-black text-lg sm:text-xl shadow-xs shrink-0">
                SCS
              </div>
              <h1 className="text-lg sm:text-2xl font-black text-white tracking-tight leading-none drop-shadow-xs">
                {t.appName}
              </h1>
            </div>

            {/* Right Action Icons */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {/* Language Switcher */}
              <button
                type="button"
                onClick={onToggleLanguage}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-extrabold text-xs sm:text-sm border border-white/20 transition cursor-pointer"
                title={language === 'bn' ? 'Switch to English' : 'বাংলায় পরিবর্তন করুন'}
              >
                <Globe className="w-4 h-4 text-white" />
                <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
              </button>

              {/* Theme Toggle */}
              <button
                type="button"
                onClick={onToggleTheme}
                className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white border border-white/20 transition cursor-pointer"
                title={theme === 'dark' ? t.lightMode : t.darkMode}
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4 text-amber-300" />
                ) : (
                  <Moon className="w-4 h-4 text-white" />
                )}
              </button>

              {/* Sync Button */}
              <button
                type="button"
                onClick={onSync}
                disabled={isSyncing}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white border border-white/20 font-bold text-xs sm:text-sm transition disabled:opacity-50 cursor-pointer"
                title={t.sync}
              >
                <RefreshCw
                  className={`w-4 h-4 text-white ${isSyncing ? 'animate-spin' : ''}`}
                />
                <span className="hidden sm:inline">{t.sync}</span>
              </button>

              {/* Logout Button */}
              <button
                type="button"
                onClick={onLogout}
                className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-black/20 hover:bg-black/35 text-white border border-white/15 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition cursor-pointer"
                title={t.logout}
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">{t.logout}</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* 2. SEPARATE MENU BAR */}
      <nav className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-xs sticky top-14 sm:top-16 z-30 transition-colors">
        <div className="max-w-6xl mx-auto px-3 sm:px-6">
          <div className="flex space-x-1.5 sm:space-x-3 overflow-x-auto py-2 scrollbar-none">
            <button
              onClick={() => onTabChange('dashboard')}
              className={`flex items-center gap-2 py-2 px-3.5 sm:px-4 rounded-xl font-black text-xs sm:text-sm whitespace-nowrap transition cursor-pointer ${
                currentTab === 'dashboard'
                  ? 'bg-[#e91e63] text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>{t.dashboard}</span>
            </button>

            <button
              onClick={() => onTabChange('attendance')}
              className={`flex items-center gap-2 py-2 px-3.5 sm:px-4 rounded-xl font-black text-xs sm:text-sm whitespace-nowrap transition cursor-pointer ${
                currentTab === 'attendance'
                  ? 'bg-[#e91e63] text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <CalendarCheck className="w-4 h-4" />
              <span>{t.attendance}</span>
            </button>

            <button
              onClick={() => onTabChange('leave')}
              className={`flex items-center gap-2 py-2 px-3.5 sm:px-4 rounded-xl font-black text-xs sm:text-sm whitespace-nowrap transition cursor-pointer ${
                currentTab === 'leave'
                  ? 'bg-[#e91e63] text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <CalendarDays className="w-4 h-4" />
              <span>{t.leaveRecord}</span>
            </button>

            <button
              onClick={() => onTabChange('admin')}
              className={`flex items-center gap-2 py-2 px-3.5 sm:px-4 rounded-xl font-black text-xs sm:text-sm whitespace-nowrap transition cursor-pointer ${
                currentTab === 'admin'
                  ? 'bg-[#e91e63] text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{t.admin}</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
};
