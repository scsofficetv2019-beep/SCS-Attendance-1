import React, { useState } from 'react';
import { Employee, AttendanceRecord } from '../types';
import {
  formatDateLocal,
  formatTimeLocal,
  formatTime12Hour,
  getAvatarUrl,
} from '../utils/storage';
import { Language, translations } from '../i18n';
import {
  Clock,
  UserPlus,
  Search,
  X,
  Navigation,
  CheckCircle2,
  RotateCw,
} from 'lucide-react';

interface AttendanceMarkingProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  onSubmitRecord: (record: AttendanceRecord) => void;
  onShowModal: (title: string, msg: string) => void;
  onShowToast: (msg: string) => void;
  language: Language;
}

export const AttendanceMarking: React.FC<AttendanceMarkingProps> = ({
  employees,
  attendance,
  onSubmitRecord,
  onShowModal,
  language,
}) => {
  const t = translations[language];
  const [selectedType, setSelectedType] = useState<'Clock IN' | 'Clock Out' | ''>('');
  const [selectedEmp, setSelectedEmp] = useState<Employee | null>(null);
  const [isEmpModalOpen, setIsEmpModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Location Real-time GPS State
  const [locationStatus, setLocationStatus] = useState<'idle' | 'locating' | 'ready' | 'error'>('idle');
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);

  // Success Persistent Modal (Must be explicitly dismissed via OK button)
  const [successModalData, setSuccessModalData] = useState<{
    empName: string;
    type: string;
    time: string;
  } | null>(null);

  // Request Real-time Location
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      setLocationStatus('error');
      onShowModal(
        t.location,
        language === 'bn' ? 'আপনার ব্রাউজারে জিপিএস সমর্থিত নয়।' : 'Geolocation not supported.'
      );
      return;
    }

    setLocationStatus('locating');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setCoords({ lat: latitude, lng: longitude });
        setLocationStatus('ready');
      },
      () => {
        setLocationStatus('error');
        onShowModal(
          t.location,
          language === 'bn'
            ? 'লোকেশন পাওয়া যায়নি। অনুগ্রহ করে জিপিএস চালু করে অনুমতি দিন।'
            : 'Unable to get location. Please enable GPS.'
        );
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  };

  // Handle Type Selection with Immediate Validation
  const handleSelectType = (type: 'Clock IN' | 'Clock Out') => {
    setSelectedType(type);

    if (selectedEmp) {
      const todayDate = formatDateLocal(new Date());
      const hasClockIn = attendance.some(
        (a) => a.empId === selectedEmp.empId && a.date === todayDate && a.type === 'Clock IN'
      );

      if (type === 'Clock IN' && hasClockIn) {
        onShowModal(
          language === 'bn' ? 'সতর্কতা' : 'Notice',
          language === 'bn'
            ? 'Already checked in\nPlease select check out'
            : 'Already checked in\nPlease select check out'
        );
      } else if (type === 'Clock Out' && !hasClockIn) {
        onShowModal(
          language === 'bn' ? 'সতর্কতা' : 'Notice',
          language === 'bn'
            ? 'Clock IN required first\nPlease select check in'
            : 'Clock IN required first\nPlease select check in'
        );
      }
    }
  };

  // Submit Attendance Record
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedType) {
      onShowModal(
        t.attendanceType,
        language === 'bn' ? 'অনুগ্রহ করে হাজিরা ধরণ নির্বাচন করুন।' : 'Please select attendance type.'
      );
      return;
    }

    if (!selectedEmp) {
      onShowModal(
        t.name,
        language === 'bn' ? 'অনুগ্রহ করে কর্মকর্তা নির্বাচন করুন।' : 'Please select an employee.'
      );
      return;
    }

    // MANDATORY LOCATION CHECK
    if (locationStatus !== 'ready' || !coords) {
      onShowModal(
        t.location,
        language === 'bn'
          ? 'অনুগ্রহ করে লোকেশন বাটনে চাপ দিয়ে রেডি করুন।'
          : 'Please capture GPS location first.'
      );
      return;
    }

    const todayDate = formatDateLocal(new Date());
    const nowTime = formatTime12Hour(formatTimeLocal(new Date()));

    // Duplicate Check
    const hasSame = attendance.some(
      (a) => a.empId === selectedEmp.empId && a.date === todayDate && a.type === selectedType
    );

    if (hasSame) {
      onShowModal(
        language === 'bn' ? 'সতর্কতা' : 'Notice',
        language === 'bn'
          ? 'Already checked in\nPlease select check out'
          : 'Already checked in\nPlease select check out'
      );
      return;
    }

    // Require Clock IN before Clock Out
    if (selectedType === 'Clock Out') {
      const hasClockIn = attendance.some(
        (a) => a.empId === selectedEmp.empId && a.date === todayDate && a.type === 'Clock IN'
      );
      if (!hasClockIn) {
        onShowModal(
          language === 'bn' ? 'সতর্কতা' : 'Notice',
          language === 'bn'
            ? 'Clock IN required first\nPlease select check in'
            : 'Clock IN required first\nPlease select check in'
        );
        return;
      }
    }

    const newRecord: AttendanceRecord = {
      id: `att-${Date.now()}`,
      empId: selectedEmp.empId,
      date: todayDate,
      type: selectedType,
      time: nowTime,
      lat: coords.lat,
      lng: coords.lng,
      locationText: `${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}`,
      createdBy: 'user',
    };

    onSubmitRecord(newRecord);

    // Show persistent Success Modal until OK is clicked
    setSuccessModalData({
      empName: selectedEmp.name,
      type: selectedType === 'Clock IN' ? t.clockIn : t.clockOut,
      time: nowTime,
    });

    // Reset Form
    setSelectedType('');
    setSelectedEmp(null);
    setCoords(null);
    setLocationStatus('idle');
  };

  const filteredEmployees = employees.filter(
    (e) =>
      e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.empId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-lg mx-auto space-y-6 animate-fade">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-7 shadow-xs border border-slate-200 dark:border-slate-800 transition-colors">
        <h2 className="text-xl sm:text-2xl font-black text-[#e91e63] mb-5 flex items-center gap-2">
          <Clock className="w-6 h-6" />
          <span>{t.markAttendance}</span>
        </h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* 1. Clock In / Out Type */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => handleSelectType('Clock IN')}
              className={`p-3.5 rounded-2xl border-2 font-black text-sm sm:text-base flex items-center justify-center gap-2 transition cursor-pointer ${
                selectedType === 'Clock IN'
                  ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 shadow-xs'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-emerald-300'
              }`}
            >
              <span>{t.clockIn}</span>
            </button>

            <button
              type="button"
              onClick={() => handleSelectType('Clock Out')}
              className={`p-3.5 rounded-2xl border-2 font-black text-sm sm:text-base flex items-center justify-center gap-2 transition cursor-pointer ${
                selectedType === 'Clock Out'
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 shadow-xs'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-blue-300'
              }`}
            >
              <span>{t.clockOut}</span>
            </button>
          </div>

          {/* 2. Employee Selector in Round Avatar Ring */}
          <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center">
            <div
              onClick={() => setIsEmpModalOpen(true)}
              className="group cursor-pointer flex flex-col items-center"
            >
              {/* Round Ring */}
              <div
                className={`w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 ${
                  selectedEmp
                    ? 'border-[#e91e63] shadow-md shadow-pink-500/20'
                    : 'border-dashed border-[#e91e63] bg-pink-50/60 dark:bg-pink-950/30'
                } p-1 flex items-center justify-center transition-transform group-hover:scale-105 bg-white dark:bg-slate-800`}
              >
                {selectedEmp ? (
                  <img
                    src={selectedEmp.photoUrl || getAvatarUrl(selectedEmp.name)}
                    alt={selectedEmp.name}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-[#e91e63] dark:text-pink-400 p-2">
                    <UserPlus className="w-7 h-7 mb-1" />
                    <span className="text-[11px] font-black leading-tight">
                      {language === 'bn' ? 'কর্মকর্তা' : 'Employee'}
                    </span>
                  </div>
                )}
              </div>

              {selectedEmp ? (
                <div className="mt-2.5">
                  <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                    {selectedEmp.name}
                  </h3>
                  <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                    {selectedEmp.empId} • {selectedEmp.designation || '-'}
                  </p>
                </div>
              ) : (
                <span className="mt-2 text-xs font-bold text-slate-500 dark:text-slate-400">
                  {language === 'bn' ? 'ছবিতে চাপ দিয়ে নির্বাচন করুন' : 'Tap to select'}
                </span>
              )}
            </div>
          </div>

          {/* 3. Real-time Location Button (Clear, short & crisp) */}
          <div>
            {locationStatus === 'idle' && (
              <button
                type="button"
                onClick={handleGetLocation}
                className="w-full py-3.5 px-4 rounded-2xl border-2 border-dashed border-[#e91e63] bg-pink-50/60 dark:bg-pink-950/20 text-[#e91e63] dark:text-pink-400 font-black text-sm flex items-center justify-center gap-2 hover:bg-pink-100 transition cursor-pointer"
              >
                <Navigation className="w-4 h-4" />
                <span>{language === 'bn' ? 'লোকেশন নিন' : 'Get Location'}</span>
              </button>
            )}

            {locationStatus === 'locating' && (
              <div className="w-full py-3.5 px-4 rounded-2xl border-2 border-[#e91e63] bg-pink-50 dark:bg-pink-950/40 text-[#e91e63] font-black text-sm flex items-center justify-center gap-2 animate-pulse">
                <RotateCw className="w-4 h-4 animate-spin" />
                <span>{language === 'bn' ? 'লোকেশন লোড হচ্ছে...' : 'Getting Location...'}</span>
              </div>
            )}

            {locationStatus === 'ready' && (
              <div className="w-full py-3 px-4 rounded-2xl border-2 border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-200 font-black text-sm flex items-center justify-center gap-2 shadow-xs">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <span>{language === 'bn' ? 'রেডি ✓' : 'Ready ✓'}</span>
              </div>
            )}

            {locationStatus === 'error' && (
              <button
                type="button"
                onClick={handleGetLocation}
                className="w-full py-3 px-4 rounded-2xl border-2 border-rose-400 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <RotateCw className="w-4 h-4" />
                <span>{language === 'bn' ? 'পুনরায় চেষ্টা করুন' : 'Retry Location'}</span>
              </button>
            )}
          </div>

          {/* Submit Attendance Button */}
          <button
            type="submit"
            disabled={locationStatus !== 'ready' || !selectedEmp || !selectedType}
            className={`w-full py-3.5 rounded-2xl font-black text-base shadow-sm transition active:scale-98 cursor-pointer flex items-center justify-center gap-2 ${
              locationStatus === 'ready' && selectedEmp && selectedType
                ? 'bg-[#e91e63] hover:bg-[#c2185b] text-white'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed opacity-60'
            }`}
          >
            <span>{t.submitAttendance}</span>
          </button>
        </form>
      </div>

      {/* Employee Search Modal */}
      {isEmpModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl border border-slate-100 dark:border-slate-800 max-h-[85vh] flex flex-col animate-fade transition-colors">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-3">
              <h3 className="text-base font-extrabold text-[#e91e63]">
                {t.selectEmployeeModalTitle}
              </h3>
              <button
                onClick={() => setIsEmpModalOpen(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Search Input */}
            <div className="relative mb-3">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={t.searchEmployeePlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white text-sm font-semibold outline-hidden focus:border-[#e91e63]"
                autoFocus
              />
            </div>

            {/* Employee List */}
            <div className="overflow-y-auto flex-1 space-y-2 pr-1">
              {filteredEmployees.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-sm font-semibold">
                  {t.noEmployees}
                </div>
              ) : (
                filteredEmployees.map((emp) => (
                  <div
                    key={emp.id}
                    onClick={() => {
                      setSelectedEmp(emp);
                      setIsEmpModalOpen(false);
                      setSearchQuery('');
                      // check if clock in / out needs prompt
                      if (selectedType === 'Clock IN') {
                        const todayDate = formatDateLocal(new Date());
                        const hasIn = attendance.some(
                          (a) => a.empId === emp.empId && a.date === todayDate && a.type === 'Clock IN'
                        );
                        if (hasIn) {
                          onShowModal(
                            language === 'bn' ? 'সতর্কতা' : 'Notice',
                            'Already checked in\nPlease select check out'
                          );
                        }
                      }
                    }}
                    className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-pink-50 dark:hover:bg-pink-950/40 border border-slate-100 dark:border-slate-800 cursor-pointer transition group"
                  >
                    <img
                      src={emp.photoUrl || getAvatarUrl(emp.name)}
                      alt={emp.name}
                      className="w-11 h-11 rounded-full object-cover border-2 border-pink-400 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-sm text-slate-900 dark:text-white group-hover:text-[#e91e63] truncate">
                        {emp.name}
                      </div>
                      <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 truncate">
                        {emp.empId} • {emp.designation || '-'}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Mandatory Persistent Attendance Submitted Popup (Must Click OK) */}
      {successModalData && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-100 dark:border-slate-800 text-center animate-fade transition-colors">
            <div className="w-14 h-14 mx-auto mb-3 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center shadow-xs">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-black text-slate-900 dark:text-white mb-1">
              {language === 'bn' ? 'অ্যাটেনডেন্স সাবমিটেড' : 'Attendance Submitted'}
            </h3>

            <div className="my-4 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-sm">
              <div className="font-black text-slate-900 dark:text-white">
                {successModalData.empName}
              </div>
              <div className="text-xs font-bold text-emerald-700 dark:text-emerald-300 mt-1">
                {successModalData.type} • {successModalData.time}
              </div>
            </div>

            <button
              type="button"
              onClick={() => setSuccessModalData(null)}
              className="w-full py-3.5 rounded-2xl bg-[#e91e63] hover:bg-[#c2185b] text-white font-black text-sm transition shadow-md cursor-pointer active:scale-98"
            >
              {language === 'bn' ? 'ঠিক আছে (OK)' : 'OK'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
