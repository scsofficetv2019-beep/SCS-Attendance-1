import React, { useState, useEffect, useCallback } from 'react';
import { Delete, KeyRound, CornerDownLeft } from 'lucide-react';
import { Language, translations } from '../i18n';
import { safeGetItem } from '../utils/storage';

interface UserLoginProps {
  onSuccess: () => void;
  onError: (message: string) => void;
  language: Language;
}

export const UserLogin: React.FC<UserLoginProps> = ({
  onSuccess,
  onError,
  language,
}) => {
  const t = translations[language];
  const [pin, setPin] = useState<string>('');

  const verifyPin = useCallback((inputPin: string) => {
    const savedPin = safeGetItem('scs_user_pin') || '2019';
    if (inputPin === savedPin) {
      setTimeout(() => {
        onSuccess();
      }, 150);
    } else {
      setTimeout(() => {
        onError(t.invalidPin);
        setPin('');
      }, 150);
    }
  }, [onError, onSuccess, t.invalidPin]);

  const handleKeyPress = useCallback((num: string) => {
    setPin((prev) => {
      if (prev.length < 4) {
        const nextPin = prev + num;
        if (nextPin.length === 4) {
          verifyPin(nextPin);
        }
        return nextPin;
      }
      return prev;
    });
  }, [verifyPin]);

  const handleBackspace = useCallback(() => {
    setPin((prev) => prev.slice(0, -1));
  }, []);

  const handleClear = useCallback(() => {
    setPin('');
  }, []);

  const handleEnter = useCallback(() => {
    if (pin.length > 0) {
      verifyPin(pin);
    }
  }, [pin, verifyPin]);

  // Keyboard Event Listener (Supports 0-9, Backspace, Enter, Esc)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleKeyPress(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        handleEnter();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyPress, handleBackspace, handleEnter, handleClear]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-radial from-slate-100 to-slate-200 dark:from-slate-950 dark:to-slate-900 p-4 transition-colors">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 dark:border-slate-800 text-center transition-colors">
        {/* App Title & Icon */}
        <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-tr from-[#c2185b] to-[#e91e63] rounded-3xl flex items-center justify-center text-white shadow-lg shadow-pink-500/30">
          <KeyRound className="w-8 h-8" />
        </div>

        <h1 className="text-2xl font-black text-[#e91e63] tracking-tight">
          {t.appName}
        </h1>
        <p className="text-slate-500 dark:text-slate-400 font-bold text-xs uppercase tracking-wider mt-1 mb-6">
          {t.userLogin}
        </p>

        {/* PIN Indicators */}
        <div className="flex justify-center items-center gap-4 mb-6">
          {[0, 1, 2, 3].map((index) => (
            <div
              key={index}
              className={`w-4 h-4 rounded-full transition-all duration-200 ${
                index < pin.length
                  ? 'bg-[#e91e63] scale-125 shadow-md shadow-pink-400/50'
                  : 'bg-slate-200 dark:bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-2.5 sm:gap-3 mb-3">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleKeyPress(digit)}
              className="h-12 sm:h-14 text-xl sm:text-2xl font-black text-slate-800 dark:text-white bg-slate-50 dark:bg-slate-800 hover:bg-pink-50 dark:hover:bg-pink-950/40 hover:text-[#e91e63] rounded-2xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
            >
              {digit}
            </button>
          ))}

          {/* Clear */}
          <button
            type="button"
            onClick={handleClear}
            className="h-12 sm:h-14 text-xs font-bold text-rose-500 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 rounded-2xl border border-rose-100 dark:border-rose-900 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
          >
            {t.clear}
          </button>

          {/* 0 */}
          <button
            type="button"
            onClick={() => handleKeyPress('0')}
            className="h-12 sm:h-14 text-xl sm:text-2xl font-black text-slate-800 dark:text-white bg-slate-50 dark:bg-slate-800 hover:bg-pink-50 dark:hover:bg-pink-950/40 hover:text-[#e91e63] rounded-2xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
          >
            0
          </button>

          {/* Backspace */}
          <button
            type="button"
            onClick={handleBackspace}
            className="h-12 sm:h-14 text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-2xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
            title="Backspace"
          >
            <Delete className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        </div>

        {/* Dedicated Enter Button */}
        <button
          type="button"
          onClick={handleEnter}
          disabled={pin.length === 0}
          className="w-full py-3 mb-4 rounded-2xl bg-gradient-to-r from-[#e91e63] to-[#c2185b] text-white font-extrabold text-sm flex items-center justify-center gap-2 hover:opacity-95 shadow-md active:scale-98 transition disabled:opacity-40 cursor-pointer"
        >
          <CornerDownLeft className="w-4 h-4" />
          <span>{language === 'bn' ? 'লগইন করুন (Enter)' : 'Login (Enter)'}</span>
        </button>
      </div>
    </div>
  );
};
