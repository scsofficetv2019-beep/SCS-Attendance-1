import React, { useState, useEffect, useCallback } from 'react';
import { Delete, Lock, X, CornerDownLeft } from 'lucide-react';
import { Language, translations } from '../i18n';

interface AdminLoginModalProps {
  isOpen: boolean;
  onSuccess: () => void;
  onClose: () => void;
  onError: (message: string) => void;
  language: Language;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onSuccess,
  onClose,
  onError,
  language,
}) => {
  const t = translations[language];
  const [pin, setPin] = useState<string>('');

  const verifyPin = useCallback((inputPin: string) => {
    if (inputPin === '2026') {
      setTimeout(() => {
        onSuccess();
        setPin('');
      }, 150);
    } else {
      setTimeout(() => {
        onError(t.invalidAdminPin);
        setPin('');
      }, 150);
    }
  }, [onError, onSuccess, t.invalidAdminPin]);

  const handleKeyPress = useCallback((num: string) => {
    setPin((prev) => {
      if (prev.length < 4) {
        const nextPin = prev + num;
        if (nextPin.length === 4) {
          verifyPin(nextPin);
        }
        return nextPin;
      }
      return prev;
    });
  }, [verifyPin]);

  const handleBackspace = useCallback(() => {
    setPin((prev) => prev.slice(0, -1));
  }, []);

  const handleClear = useCallback(() => {
    setPin('');
  }, []);

  const handleEnter = useCallback(() => {
    if (pin.length > 0) {
      verifyPin(pin);
    }
  }, [pin, verifyPin]);

  // Keyboard Event Listener (Supports 0-9, Backspace, Enter, Esc)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleKeyPress(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        handleEnter();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, handleKeyPress, handleBackspace, handleEnter, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-100 dark:border-slate-800 text-center relative animate-fade transition-colors">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-1 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition cursor-pointer"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Admin Lock Icon */}
        <div className="w-14 h-14 mx-auto mb-3 bg-pink-100 dark:bg-pink-950/60 text-[#e91e63] dark:text-pink-400 rounded-2xl flex items-center justify-center shadow-xs">
          <Lock className="w-7 h-7" />
        </div>

        <h3 className="text-xl font-extrabold text-slate-900 dark:text-white mb-1">
          {t.adminLogin}
        </h3>
        <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-6">
          {t.enterAdminPin}
        </p>

        {/* PIN Dots */}
        <div className="flex justify-center items-center gap-4 mb-5">
          {[0, 1, 2, 3].map((index) => (
            <div
              key={index}
              className={`w-3.5 h-3.5 rounded-full transition-all duration-200 ${
                index < pin.length
                  ? 'bg-[#e91e63] scale-125 shadow-md shadow-pink-400/50'
                  : 'bg-slate-200 dark:bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-2 sm:gap-2.5 mb-3">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleKeyPress(digit)}
              className="h-11 sm:h-13 text-lg sm:text-xl font-extrabold text-slate-800 dark:text-white bg-slate-50 dark:bg-slate-800 hover:bg-pink-50 dark:hover:bg-pink-950/40 hover:text-[#e91e63] rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
            >
              {digit}
            </button>
          ))}

          {/* Clear */}
          <button
            type="button"
            onClick={handleClear}
            className="h-11 sm:h-13 text-xs font-bold text-rose-500 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 rounded-xl border border-rose-100 dark:border-rose-900 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
          >
            {t.clear}
          </button>

          {/* 0 */}
          <button
            type="button"
            onClick={() => handleKeyPress('0')}
            className="h-11 sm:h-13 text-lg sm:text-xl font-extrabold text-slate-800 dark:text-white bg-slate-50 dark:bg-slate-800 hover:bg-pink-50 dark:hover:bg-pink-950/40 hover:text-[#e91e63] rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
          >
            0
          </button>

          {/* Backspace */}
          <button
            type="button"
            onClick={handleBackspace}
            className="h-11 sm:h-13 text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition flex items-center justify-center select-none cursor-pointer"
            title="Backspace"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Enter Button */}
        <button
          type="button"
          onClick={handleEnter}
          disabled={pin.length === 0}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#e91e63] to-[#c2185b] text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 hover:opacity-95 shadow-md active:scale-98 transition disabled:opacity-40 cursor-pointer mb-2"
        >
          <CornerDownLeft className="w-4 h-4" />
          <span>{language === 'bn' ? 'এডমিন প্রবেশ (Enter)' : 'Enter Admin'}</span>
        </button>
      </div>
    </div>
  );
};
