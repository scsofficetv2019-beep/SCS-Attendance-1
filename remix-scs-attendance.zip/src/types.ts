export interface Employee {
  id: string;
  name: string;
  empId: string;
  designation: string;
  department: string;
  mobile: string;
  photoUrl: string;
  created: string;
  sortOrder: number;
}

export interface AttendanceRecord {
  id: string;
  empId: string;
  date: string; // YYYY-MM-DD
  type: 'Clock IN' | 'Clock Out';
  time: string; // e.g. "09:12 AM"
  lat?: string | number;
  lng?: string | number;
  locationText?: string;
  note?: string;
  createdBy?: 'user' | 'admin';
}

export interface OfficeSetup {
  officeInTime: string; // "09:00"
  officeOutTime: string; // "17:00"
  maxLateMinutes: string; // "15"
  holidays: string[]; // e.g. ["2026-09-25 (Friday)"]
}

export interface DriveSetup {
  folderId: string;
  folderUrl: string;
}

export interface DayStatus {
  day: number;
  fullDate: string; // YYYY-MM-DD
  dayName: string; // e.g. "Monday"
  status: 'Present' | 'Present with Late' | 'Present (Holiday)' | 'Holiday' | 'Absent';
  lateText: string; // e.g. "+15 min"
  inTime: string;
  outTime: string;
  workingHours: string;
  inLocation: { lat: string | number; lng: string | number } | null;
  outLocation: { lat: string | number; lng: string | number } | null;
  reason?: string;
}

export interface LateDetail {
  date: string;
  time: string;
  lateMinutes: number;
}

export interface EmployeeMonthlyReport {
  employee: Employee;
  summary: {
    present: number;
    absent: number;
    late: number;
  };
  lateDetails: LateDetail[];
  days: DayStatus[];
}

export interface MonthlyReportData {
  month: string; // YYYY-MM
  monthLabel: string; // "Sep 2026"
  daysInMonth: number;
  report: EmployeeMonthlyReport[];
  officeInTime: string;
  officeOutTime: string;
  holidays: string[];
}
